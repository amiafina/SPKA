<?php
session_start();
include 'inc/connect.php';

// Default nilai
$nama_bilik = isset($_POST['bilik']) ? $_POST['bilik'] : '';
$tarikh_pilih = isset($_POST['tarikh']) ? date('Y-m-d', strtotime($_POST['tarikh'])) : date('Y-m-d');

$bil_hadir = 0;
$bil_tak_hadir = 0;

// =========================
// DROPDOWN BILIK
// =========================
// Ambil semua bilik dari table PENGHUNI (bukan table lain)
$bilik_result = mysqli_query($conn, "
    SELECT DISTINCT nama_bilik 
    FROM penghuni 
    ORDER BY nama_bilik ASC
");

// =========================
// Admin tekan HANTAR
// =========================
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id_penghuni'])) {

    $hadir = isset($_POST['hadir']) ? $_POST['hadir'] : [];

    foreach ($_POST['id_penghuni'] as $id) {

        $status = in_array($id, $hadir) ? 1 : 0;  
        $catatan = $_POST['catatan'][$id] ?? '';
        $lain = $_POST['lain'][$id] ?? '';

        if($catatan == 'Lain-lain' && $lain != ''){
            $catatan = $lain;
        }

        // Simpan ke table kehadiran — REPLACE untuk update atau insert
        mysqli_query($conn, "
            REPLACE INTO kehadiran (id_penghuni, tarikh, status, catatan)
            VALUES ('$id', '$tarikh_pilih', '$status', '$catatan')
        ");
    }
}

// =========================
// TARIK DATA PENGHUNI + KEHADIRAN
// =========================
$result = [];
if($nama_bilik != ''){

    $query = "
        SELECT 
            p.id_penghuni,
            p.nama_penghuni,
            IFNULL(k.status,1) AS status,    -- DEFAULT = HADIR
            IFNULL(k.catatan,'') AS catatan
        FROM penghuni p
        LEFT JOIN kehadiran k
            ON p.id_penghuni = k.id_penghuni
            AND k.tarikh = '$tarikh_pilih'
        WHERE p.nama_bilik = '$nama_bilik'
        ORDER BY p.nama_penghuni ASC
    ";

    $result = mysqli_query($conn, $query);

    // Kira bilangan
    if($result && mysqli_num_rows($result) > 0){
        while($row = mysqli_fetch_assoc($result)){
            if($row['status']==1) $bil_hadir++;
        }
        $bil_tak_hadir = mysqli_num_rows($result) - $bil_hadir;
        mysqli_data_seek($result,0);
    }
}
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <title>Kehadiran</title>
    <link rel="stylesheet" href="css/style_sidebar.css">
    <link rel="stylesheet" href="../pengguna/css/style.css">
    <style>
        main.content { margin-left: 240px; padding: 20px; width: calc(100% - 260px); }
        table, th, td { border: 1px solid black; border-collapse: collapse; }
        th, td { padding: 8px; text-align: center; }
        .catatanSelect { width: 150px; }
        .lainInput { width: 150px; }
    </style>
</head>

<body class="dashboard-page">

<!-- SIDEBAR -->
<aside class="sidebar">
    <h2>SPKA</h2>
    <ul class="sidebar-menu">
      <li><a href="dashboard_admin.php"><img src="inc/gambar/dashboard.png" class="icon"> <span>Papan Muka</span></a></li>
      <li class="active"><a href="kehadiran.php"><img src="inc/gambar/kehadiran.png" class="icon"> <span>Kehadiran</span></a></li>
      <li><a href="laporan_bulanan.php"><img src="inc/gambar/laporan.png" class="icon"> <span>Laporan Bulanan</span></a></li>
      <li><a href="info.php"><img src="inc/gambar/info.png" class="icon"> <span>Info</span></a></li>
      <li><a href="maklumat_penghuni.php"><img src="inc/gambar/user.png" class="icon"> <span>Maklumat Penghuni</span></a></li>
    </ul>
</aside>

<!-- CONTENT -->
<main class="content">
<form method="POST">

    <div class="form-group">
        <label>BILIK:</label>
        <select name="bilik" onchange="this.form.submit()">
            <option value="">-- Pilih Bilik --</option>
            <?php while($b = mysqli_fetch_assoc($bilik_result)) { ?>
                <option value="<?= $b['nama_bilik'] ?>" <?= ($b['nama_bilik']==$nama_bilik)?"selected":"" ?>>
                    <?= $b['nama_bilik'] ?>
                </option>
            <?php } ?>
        </select>
    </div>

    <div class="form-group">
        <label>TARIKH:</label>
        <input type="date" name="tarikh" value="<?= $tarikh_pilih ?>" max="<?= date('Y-m-d') ?>" onchange="this.form.submit()">
    </div>

<?php if(!empty($result) && mysqli_num_rows($result) > 0) { ?>

    <hr>
    <div class="form-group">
        <label>BIL. HADIR:</label>
        <input type="text" value="<?= $bil_hadir ?>" readonly>
    </div>

    <div class="form-group">
        <label>BIL. TIDAK HADIR:</label>
        <input type="text" value="<?= $bil_tak_hadir ?>" readonly>
    </div>

    <table>
        <thead>
            <tr>
                <th>BIL.</th>
                <th>KEHADIRAN</th>
                <th>NAMA PENGHUNI</th>
                <th>CATATAN</th>
            </tr>
        </thead>

        <tbody>
            <?php $i=1; while($row = mysqli_fetch_assoc($result)){ 
                $checked = ($row['status']==1) ? "checked" : "";
                $catatan_simpan = $row['catatan'];
            ?>
            <tr>
                <td><?= $i++; ?></td>

                <td>
                    <input type="checkbox" name="hadir[]" value="<?= $row['id_penghuni'] ?>" <?= $checked ?>>
                </td>

                <td><?= $row['nama_penghuni'] ?></td>

                <td>
                    <select name="catatan[<?= $row['id_penghuni'] ?>]" class="catatanSelect">
                        <option value="" <?= ($catatan_simpan=="")?"selected":"" ?>>Sila pilih</option>
                        <option value="Sakit" <?= ($catatan_simpan=="Sakit")?"selected":"" ?>>Sakit</option>
                        <option value="Balik kampung" <?= ($catatan_simpan=="Balik kampung")?"selected":"" ?>>Balik kampung</option>
                        <option value="Lain-lain" <?= ($catatan_simpan!="" && $catatan_simpan!="Sakit" && $catatan_simpan!="Balik kampung")?"selected":"" ?>>Lain-lain</option>
                    </select>

                    <input type="text" 
                           name="lain[<?= $row['id_penghuni'] ?>]" 
                           class="lainInput"
                           value="<?= ($catatan_simpan!="" && $catatan_simpan!="Sakit" && $catatan_simpan!="Balik kampung")?$catatan_simpan:'' ?>"
                           style="<?= ($catatan_simpan!="" && $catatan_simpan!="Sakit" && $catatan_simpan!="Balik kampung")?'display:inline':'display:none' ?>"
                           placeholder="Sila taip">
                </td>
            </tr>

            <input type="hidden" name="id_penghuni[]" value="<?= $row['id_penghuni'] ?>">

            <?php } ?>
        </tbody>
    </table>

    <div style="margin-top:10px; text-align:right;">
        <button type="submit" style="width:100px;">HANTAR</button>
    </div>

<?php } ?>

</form>

<div class="footer">
    <b><p>© 2025 SPKA | SISTEM PENGURUSAN KEHADIRAN ASRAMA</p></b>
</div>

</main>

<script>
// show/hide input lain-lain
document.querySelectorAll('.catatanSelect').forEach(function(select){
    select.addEventListener('change', function(){
        let inputLain = this.nextElementSibling;
        if(this.value == 'Lain-lain'){
            inputLain.style.display = 'inline';
        } else {
            inputLain.style.display = 'none';
            inputLain.value = '';
        }
    });
});
</script>

</body>
</html>
