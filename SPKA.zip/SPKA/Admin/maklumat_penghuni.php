<?php
session_start();
include 'inc/connect.php'; // sambungan DB

function e($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
/* Messages */
$msg = '';
$msg_class = '';

/* Handle POST actions: edit save, delete confirm */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mode = $_GET['mode'] ?? '';
    if ($mode === 'edit' && isset($_GET['id_penghuni'])) {
        $id_penghuni = intval($_GET['id_penghuni']);
        $nama_penghuni = $_POST['nama_penghuni'] ?? '';
        $no_tel = $_POST['no_tel'] ?? '';
        $kelas = $_POST['kelas'] ?? '';
        $nama_bilik = $_POST['bilik'] ?? '';
        $nama_ibu = $_POST['nama_ibu'] ?? '';
        $no_tel_ibu = $_POST['no_tel_ibu'] ?? '';
        $nama_bapa = $_POST['nama_bapa'] ?? '';
        $no_tel_bapa = $_POST['no_tel_bapa'] ?? '';
        $alamat = $_POST['alamat'] ?? '';

        $sql = "UPDATE penghuni 
                SET nama_penghuni = ?, no_tel = ?, kelas = ?, nama_bilik = ?, 
                    nama_ibu = ?, no_tel_ibu = ?, nama_bapa = ?, no_tel_bapa = ?, alamat = ? 
                WHERE id_penghuni = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('sssssssssi', $nama_penghuni, $no_tel, $kelas, $nama_bilik,
                          $nama_ibu, $no_tel_ibu, $nama_bapa, $no_tel_bapa, $alamat, $id_penghuni);
        if ($stmt->execute()) {
            $bilik_redirect = $_GET['bilik'] ?? $nama_bilik;
            header('Location: maklumat_penghuni.php?msg=' . urlencode('Kemaskini berjaya.') . '&bilik=' . urlencode($bilik_redirect));
            exit;
        } else {
            $msg = "Ralat: Gagal kemaskini.";
            $msg_class = "msg-error";
        }
        $stmt->close();
    } elseif ($mode === 'delete' && isset($_GET['id_penghuni'])) {
        $id_penghuni = intval($_GET['id_penghuni']);
        if (isset($_POST['confirm']) && $_POST['confirm'] === 'yes') {
            $stmt = $conn->prepare("DELETE FROM penghuni WHERE id_penghuni = ?");
            $stmt->bind_param('i', $id_penghuni);
            if ($stmt->execute()) {
                $bilik_redirect = $_GET['bilik'] ?? '';
                header('Location: maklumat_penghuni.php?msg=' . urlencode('Padam berjaya.') . '&bilik=' . urlencode($bilik_redirect));
                exit;
            } else {
                $msg = "Ralat: Gagal padam rekod.";
                $msg_class = "msg-error";
            }
            $stmt->close();
        } else {
            header('Location: maklumat_penghuni.php');
            exit;
        }
    }

// Papar mesej (di bahagian atas page)
if(isset($_SESSION['msg'])){
    echo '<div class="'.$_SESSION['msg_class'].'">'.htmlspecialchars($_SESSION['msg']).'</div>';
    unset($_SESSION['msg'], $_SESSION['msg_class']);
}

}

/* Optional: show message from GET */
if (isset($_GET['msg'])) {
    $msg = e($_GET['msg']);
    $msg_class = 'msg-success';
}

/* Helper: get distinct dorms (bilik) */
$dorms = [];
$res = $conn->query("SELECT nama_bilik FROM bilik ORDER BY nama_bilik ASC");
if ($res) {
    while ($r = $res->fetch_assoc()) {
        $dorms[] = $r['nama_bilik'];
    }
    $res->free();
}

/* Determine mode */
$mode = $_GET['mode'] ?? 'list';

/* Bilik yang dipilih untuk paparan table */
$selected_dorm = $_GET['bilik'] ?? '';
$search = trim($_GET['q'] ?? '');
?>
<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Maklumat Penghuni</title>
<link rel="stylesheet" href="css/style_sidebar.css">
<link rel="stylesheet" href="css/style_maklumat.css">

<!-- JAVA SCRIPT -->
<script>

function confirmDelete(event, name) {
    if (!confirm("Adakah anda ingin memadam rekod: " + name + " ?")) {
        event.preventDefault();
        return false;
    }
    return true;
    
}

function logoutConfirm(event) {
    event.preventDefault(); // hentikan default link
    Swal.fire({
        title: 'Adakah anda ingin keluar?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya',
        cancelButtonText: 'Tidak',
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            // redirect ke page logout
            window.location.href = '../Admin/index.php';
        }
    });
}
</script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>



</head>
<body class="dashboard-page">

<!-- Sidebar -->
<aside class="sidebar">
    <h2>SPKA</h2>
    <ul class="sidebar-menu">
      <li><a href="dashboard_admin.php"><img src="inc/gambar/dashboard.png" class="icon"><span>Papan Muka</span></a></li>
      <li><a href="kehadiran.php"><img src="inc/gambar/kehadiran.png" class="icon"><span>Kehadiran</span></a></li>
      <li><a href="laporan_bulanan.php"><img src="inc/gambar/laporan.png" class="icon"><span>Laporan Bulanan</span></a></li>
      <li><a href="info.php"><img src="inc/gambar/info.png" class="icon"><span>Info</span></a></li>
      <li class="active"><a href="maklumat_penghuni.php"><img src="inc/gambar/user.png" class="icon"><span>Maklumat Penghuni</span></a></li>
      <li><a href="tambah_penghuni"><img src="inc/gambar/add.png" class="icon"><span>Tambah Penghuni</span></a></li>
      <br><br>
      <li>
        <a href="index.php" onclick="return logoutConfirm(event)">
            <img src="inc/gambar/logout.png" class="icon">
            <span>Log Keluar</span>
        </a>
      </li>

    </ul>
</aside>

<div class="content">

<div class="container">
<h2>Maklumat Pelajar</h2>
<?php if($msg): ?>
    <div class="msg <?= e($msg_class) ?>"><?= e($msg) ?></div>
<?php endif; ?>

<?php
// ---------------- VIEW MODE ----------------

if($mode==='view' && isset($_GET['id_penghuni'])):
    $id_penghuni = intval($_GET['id_penghuni']);
    $stmt = $conn->prepare("SELECT * FROM penghuni WHERE id_penghuni=?");
    $stmt->bind_param("i",$id_penghuni);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $stmt->close();
    if($row):

?>
    <a class="back-link" href="maklumat_penghuni.php?bilik=<?= urlencode($row['nama_bilik']) ?>">&larr; Kembali ke senarai</a>
    <div class="detail-card">
        <div class="detail-row"><div class="detail-label">Nama:</div><div class="detail-value"><?= e($row['nama_penghuni']) ?></div></div>
        <div class="detail-row"><div class="detail-label">Kelas:</div><div class="detail-value"><?= e($row['kelas']) ?></div></div>
        <div class="detail-row"><div class="detail-label">Bilik:</div><div class="detail-value"><?= e($row['nama_bilik']) ?></div></div>
        <div class="detail-row"><div class="detail-label">No Telefon:</div><div class="detail-value"><?= e($row['no_tel']) ?></div></div>
        <div class="detail-row"><div class="detail-label">Nama Ibu:</div><div class="detail-value"><?= e($row['nama_ibu']) ?></div></div>
        <div class="detail-row"><div class="detail-label">No Telefon Ibu:</div><div class="detail-value"><?= e($row['no_tel_ibu']) ?></div></div>
        <div class="detail-row"><div class="detail-label">Nama Bapa:</div><div class="detail-value"><?= e($row['nama_bapa']) ?></div></div>
        <div class="detail-row"><div class="detail-label">No Telefon Bapa:</div><div class="detail-value"><?= e($row['no_tel_bapa']) ?></div></div>
        <div class="detail-row"><div class="detail-label">Alamat Rumah:</div><div class="detail-value"><?= nl2br(e($row['alamat'])) ?></div></div>
        <div class="form-actions" style="margin-top:30px;">   
            <a class="btn btn-edit" href="maklumat_penghuni.php?mode=edit&id_penghuni=<?= $row['id_penghuni'] ?>">Kemaskini</a>
            <form style="display:inline-block" method="post" action="maklumat_penghuni.php?mode=delete&id_penghuni=<?= $row['id_penghuni'] ?>&bilik=<?= urlencode($row['nama_bilik']) ?>"
                  onsubmit="return confirmDelete(event, '<?= addslashes($row['nama_penghuni']) ?>');">
                <input type="hidden" name="confirm" value="yes">
                <button class="btn btn-delete" type="submit">Padam</button>
            </form>
        </div>
    </div>
<?php else: ?>
    <div class="msg msg-error">Rekod tidak dijumpai.</div>
<?php endif; endif; ?>

<?php
// ---------------- EDIT MODE ----------------
if($mode==='edit' && isset($_GET['id_penghuni'])):
    $id_penghuni = intval($_GET['id_penghuni']);
    $stmt = $conn->prepare("SELECT * FROM penghuni WHERE id_penghuni=?");
    $stmt->bind_param("i",$id_penghuni);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $stmt->close();
    if($row):
?>
    <a class="back-link" href="maklumat_penghuni.php?bilik=<?= urlencode($row['nama_bilik']) ?>">&larr; Kembali ke senarai</a>
    <h3>Kemaskini Maklumat: <?= e($row['nama_penghuni']) ?></h3>
    <form method="post" action="maklumat_penghuni.php?mode=edit&id_penghuni=<?= $row['id_penghuni'] ?>&bilik=<?= urlencode($row['nama_bilik']) ?>">
        <div class="form-grid">
            <div class="form-row"><label>Nama</label><input name="nama_penghuni" required value="<?= e($row['nama_penghuni']) ?>"></div>
            <div class="form-row"><label>No Telefon</label><input name="no_tel" value="<?= e($row['no_tel']) ?>"></div>
            <div class="form-row"><label>Kelas</label><input name="kelas" value="<?= e($row['kelas']) ?>"></div>
            <div class="form-row"><label>Bilik</label>
                <select name="bilik">
                    <option value="">-- Pilih Bilik --</option>
                    <?php foreach($dorms as $d): ?>
                        <option value="<?= e($d) ?>" <?= ($row['nama_bilik']==$d)?'selected':'' ?>><?= e($d) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-row"><label>Nama Ibu</label><input name="nama_ibu" value="<?= e($row['nama_ibu']) ?>"></div>
            <div class="form-row"><label>No Telefon Ibu</label><input name="no_tel_ibu" value="<?= e($row['no_tel_ibu']) ?>"></div>
            <div class="form-row"><label>Nama Bapa</label><input name="nama_bapa" value="<?= e($row['nama_bapa']) ?>"></div>
            <div class="form-row"><label>No Telefon Bapa</label><input name="no_tel_bapa" value="<?= e($row['no_tel_bapa']) ?>"></div>
            <div class="form-row" style="grid-column:1/-1"><label>Alamat</label><textarea name="alamat" rows="3"><?= e($row['alamat']) ?></textarea></div>
        </div>
        <div class="form-actions">
            <button type="submit" class="btn btn-view">Simpan</button>
            <a class="btn" href="maklumat_penghuni.php?bilik=<?= urlencode($row['nama_bilik']) ?>">Batal</a>
        </div>
    </form>
<?php else: ?>
    <div class="msg msg-error">Rekod tidak dijumpai untuk diedit.</div>
<?php endif; endif; ?>

<?php
// ---------------- LIST MODE ----------------
if($mode==='list'):
?>
<div class="header-bar">
  <div class="left-controls">
    <form id="filterForm" method="get" style="display:flex;gap:8px;align-items:center;">
      <label for="dorm">Pilih Bilik:</label>
      <select id="dorm" name="bilik" onchange="this.form.submit();">
        <option value="">-- Semua Bilik --</option>
        <?php foreach ($dorms as $d): ?>
          <option value="<?= e($d) ?>" <?= ($selected_dorm===$d)?'selected':'' ?>><?= e($d) ?></option>
        <?php endforeach; ?>
      </select>
    </form>
  </div>
  <div class="right-controls">
    <form method="get" style="display:flex;gap:8px;align-items:center;">
      <input type="hidden" name="bilik" value="<?= e($selected_dorm) ?>">
      <input type="search" name="q" placeholder="Cari nama..." value="<?= e($search) ?>">
      <button class="btn" type="submit">Cari</button>
      <a href="maklumat_penghuni.php" class="btn">Set Semula</a>
    </form>
  </div>
</div>

<div class="table-wrap">
  <table class="table">
    <thead>
      <tr>
        <th>Bil</th>
        <th>Nama</th>
        <th>No Telefon</th>
        <th>Kelas</th>
        <th>Perkara</th>
      </tr>
    </thead>
    <tbody>
      <tbody>
<?php

// ===============================
//  CARIAN TANPA PILIH BILIK
// ===============================

if ($search !== '') {
    // Carian GLOBAL — tanpa ikut bilik
    $sql = "SELECT * FROM penghuni WHERE nama_penghuni LIKE ? ORDER BY nama_penghuni ASC";
    $stmt = $conn->prepare($sql);
    $like = "%$search%";
    $stmt->bind_param("s", $like);

} elseif ($selected_dorm !== '') {
    // Carian ikut bilik sahaja
    $sql = "SELECT * FROM penghuni WHERE nama_bilik=? ORDER BY nama_penghuni ASC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $selected_dorm);

} else {
    // Tiada carian & tiada bilik dipilih
    echo '<tr><td colspan="5">Sila pilih bilik atau masukkan carian.</td></tr>';
    return;
}

$stmt->execute();
$res = $stmt->get_result();

$i = 1;
while($r = $res->fetch_assoc()):
?>
    <tr>
        <td><?= $i ?></td>
        <td><a class="name-link"
               href="maklumat_penghuni.php?mode=view&id_penghuni=<?= $r['id_penghuni'] ?>">
               <?= e($r['nama_penghuni']) ?>
            </a>
        </td>
        <td><?= e($r['no_tel']) ?></td>
        <td><?= e($r['kelas']) ?></td>
        <td>
            <a class="btn btn-edit"
               href="maklumat_penghuni.php?mode=edit&id_penghuni=<?= $r['id_penghuni'] ?>">
               Kemaskini
            </a>
            <form style="display:inline-block" method="post"
                action="maklumat_penghuni.php?mode=delete&id_penghuni=<?= $r['id_penghuni'] ?>&bilik=<?= urlencode($r['nama_bilik']) ?>"
                onsubmit="return confirmDelete(event, <?= json_encode($r['nama_penghuni']) ?>);">
                <input type="hidden" name="confirm" value="yes">
                <button class="btn btn-delete" type="submit">Padam</button>
            </form>





<script>
function confirmDelete(event, name) {
    if (!confirm("Adakah anda ingin memadam: " + name + "?")) {
        event.preventDefault();
        return false;
    }
    return true;
}
</script>

        </td>
    </tr>
<?php
$i++;
endwhile;

if ($i === 1) {
    echo '<tr><td colspan="5">Tiada rekod dijumpai.</td></tr>';
}
?>
</tbody>

    </tbody>
  </table>
</div>
<?php endif; ?>

</div>
</body>
</html>
