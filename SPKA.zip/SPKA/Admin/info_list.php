<?php
include 'inc/connect.php';

// DELETE FAIL
if(isset($_GET['delete'])){
    $id = (int)$_GET['delete'];

    $q = mysqli_query($conn, "SELECT filename FROM info_files WHERE id=$id");
    $row = mysqli_fetch_assoc($q);

    if($row){
        unlink("uploads/info/".$row['filename']);
        mysqli_query($conn, "DELETE FROM info_files WHERE id=$id");
        echo "<script>alert('Fail dipadam!');</script>";
    }
}

// UPDATE TAJUK
if(isset($_POST['save'])){
    $id = (int)$_POST['id'];
    $title = mysqli_real_escape_string($conn, $_POST['title']);

    mysqli_query($conn, "UPDATE info_files SET title='$title' WHERE id=$id");
    echo "<script>alert('Tajuk dikemaskini!');</script>";
}

$result = mysqli_query($conn, "SELECT * FROM info_files ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8">
<title>Senarai Info Admin</title>
<link rel="stylesheet" href="css/style_sidebar.css">
<!-- SWEETALERT -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
<style>
/* CSS sama seperti sebelum ini */
body {
    font-family: 'Poppins', sans-serif;
    background: #f5f6fa;
    margin: 0;
}
.content {
    margin-left: 260px;
    padding: 30px;
}
h3 {
    font-size: 28px;
    font-weight: 700;
    margin-bottom: 25px;
    color: #2c3e50;
}
table {
    width: 100%;
    max-width: 1000px;
    margin: 0 auto;
    border-collapse: collapse;
    background: #ffffff;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 5px 20px rgba(0,0,0,0.08);
}
table th {
    background: #3498db;
    color: white;
    padding: 15px;
    font-size: 15px;
    text-align: left;
}
table td {
    padding: 12px 15px;
    border-bottom: 1px solid #eee;
}
table input[type="text"] {
    width: 90%;
    padding: 7px 10px;
    border-radius: 6px;
    border: 1px solid #ccc;
}
table button {
    background: #2ecc71;
    border: none;
    padding: 7px 12px;
    color: white;
    font-weight: 600;
    border-radius: 6px;
    cursor: pointer;
}
table a[href*="delete"] {
    color: #e74c3c;
    text-decoration: none;
}
.btn-back {
    display: inline-block;
    padding: 6px 10px;
    background: #3498db;
    color: white;
    border-radius: 6px;
    text-decoration: none;
    margin-bottom: 15px;
}
</style>
</head>
<body>

<aside class="sidebar">
    <h2>SPKA</h2>
    <ul class="sidebar-menu">
        <li><a href="dashboard_admin.php"><img src="inc/gambar/dashboard.png" class="icon"><span>Papan Muka</span></a></li>
        <li><a href="kehadiran.php"><img src="inc/gambar/kehadiran.png" class="icon"><span>Kehadiran</span></a></li>
        <li><a href="laporan_bulanan.php"><img src="inc/gambar/laporan.png" class="icon"><span>Laporan Bulanan</span></a></li>
        <li class="active"><a href="info.php"><img src="inc/gambar/info.png" class="icon"><span>Info</span></a></li>
        <li><a href="maklumat_penghuni.php"><img src="inc/gambar/user.png" class="icon"><span>Maklumat Penghuni</span></a></li>
        <li><a href="tambah_penghuni.php"><img src="inc/gambar/add.png" class="icon"><span>Tambah Penghuni</span></a></li>
        <br><br>
        <li>
            <a href="index.php" onclick="return confirmLogout(event)">
                <img src="inc/gambar/logout.png" class="icon"><span>Log Keluar</span>
            </a>
        </li>
    </ul>
</aside>

<main class="content">
    <h3>Senarai Info Admin</h3>
    
    <table>
        <tr>
            <th>ID</th>
            <th>Tajuk</th>
            <th>Fail</th>
            <th>Tindakan</th>
        </tr>

        <?php $no = 1; while($row = mysqli_fetch_assoc($result)): ?>
        <tr>
            <td><?= $no++ ?></td>
            <td>
                <!-- FORM DENGAN POPUP -->
                <form method="post" class="edit-form" id="form_<?= $row['id'] ?>">
                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                    <input type="text" name="title" value="<?= htmlspecialchars($row['title']) ?>"
                           id="title_<?= $row['id'] ?>">
                    <br><br>
                    <!-- BUTTON DENGAN POPUP SWEETALERT -->
                    <button type="button" onclick="confirmSave(<?= $row['id'] ?>)">Save</button>
                </form>
            </td>
            <td>
                <a href="uploads/info/<?= $row['filename'] ?>" target="_blank">
                    <?= $row['filename'] ?>
                </a>
            </td>
            <td>
                <a href="#" onclick="confirmDelete(<?= $row['id'] ?>, '<?= htmlspecialchars(addslashes($row['title'])) ?>')">Padam</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
    
    <p>
        <a href="info.php" class="btn-back">← Kembali</a>
    </p>
</main>

<!-- SWEETALERT JS -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
// Function untuk logout confirmation
function confirmLogout(event) {
    event.preventDefault();
    
    Swal.fire({
        title: 'Log Keluar?',
        text: 'Adakah anda pasti ingin log keluar?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Ya, Log Keluar',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'index.php';
        }
    });
}

// Function untuk delete confirmation
function confirmDelete(id, title) {
    Swal.fire({
        title: 'Padam Maklumat?',
        html: 'Anda akan memadam:<br><b>"' + title + '"</b>',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, Padam',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = '?delete=' + id;
        }
    });
}

// Function untuk save confirmation - INI YANG BERFUNGSI
function confirmSave(id) {
    // Dapatkan nilai dari input
    var titleInput = document.getElementById('title_' + id);
    var title = titleInput.value.trim();
    
    // Validation
    if(title === '') {
        Swal.fire({
            icon: 'warning',
            title: 'Tajuk Kosong',
            text: 'Sila masukkan tajuk sebelum save',
            confirmButtonText: 'OK',
            confirmButtonColor: '#f39c12'
        });
        titleInput.focus();
        return;
    }
    
    // Tanya confirmation
    Swal.fire({
        title: 'Simpan Perubahan?',
        text: 'Adakah anda pasti ingin menyimpan perubahan?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Ya, Simpan',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#6c757d'
    }).then((result) => {
        if (result.isConfirmed) {
            // Submit form secara manual
            document.getElementById('form_' + id).submit();
        }
    });
}

// Alert untuk success messages
document.addEventListener('DOMContentLoaded', function() {
    <?php if(isset($_GET['delete'])): ?>
    Swal.fire({
        icon: 'success',
        title: 'Berjaya Dipadam!',
        text: 'Maklumat telah berjaya dipadam.',
        confirmButtonText: 'OK',
        confirmButtonColor: '#3085d6'
    });
    <?php endif; ?>
    
    <?php if(isset($_POST['save'])): ?>
    Swal.fire({
        icon: 'success',
        title: 'Berjaya Dikemaskini!',
        text: 'Tajuk telah berjaya dikemaskini.',
        confirmButtonText: 'OK',
        confirmButtonColor: '#3085d6'
    });
    <?php endif; ?>
});
</script>
</body>
</html>



<?php
include 'inc/connect.php';

if(isset($_GET['delete'])){
    $id = (int)$_GET['delete'];
    $q = mysqli_query($conn, "SELECT filename FROM info_files WHERE id=$id");
    $row = mysqli_fetch_assoc($q);
    if($row){
        unlink("uploads/info/".$row['filename']);
        mysqli_query($conn, "DELETE FROM info_files WHERE id=$id");
    }
}

if(isset($_POST['save'])){
    $id = (int)$_POST['id'];
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    mysqli_query($conn, "UPDATE info_files SET title='$title' WHERE id=$id");
}

$result = mysqli_query($conn, "SELECT * FROM info_files ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8">
<title>Senarai Info Admin</title>
<link rel="stylesheet" href="css/style_sidebar.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
<style>
/* CSS sama */
</style>
</head>
<body>

<aside class="sidebar">
    <!-- Sidebar sama -->
</aside>

<main class="content">
    <h3>Senarai Info Admin</h3>
    
    <table>
        <tr><th>ID</th><th>Tajuk</th><th>Fail</th><th>Tindakan</th></tr>

        <?php $no = 1; while($row = mysqli_fetch_assoc($result)): ?>
        <tr>
            <td><?= $no++ ?></td>
            <td>
                <!-- FORM SANGAT MUDAH -->
                <form method="post" id="form_<?= $row['id'] ?>">
                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                    <input type="text" name="title" value="<?= htmlspecialchars($row['title']) ?>"
                           id="input_<?= $row['id'] ?>">
                    <br><br>
                    <!-- BUTTON TYPE="submit" DENGAN SIMPLE VALIDATION -->
                    <button type="submit" name="save" onclick="return simpleConfirm(<?= $row['id'] ?>)">
                        Save
                    </button>
                </form>
                
                <script>
                function simpleConfirm(id) {
                    var input = document.getElementById('input_' + id);
                    if(input.value.trim() === '') {
                        Swal.fire({
                            icon: 'warning',
                            title: 'Tajuk Kosong',
                            text: 'Sila isi tajuk'
                        });
                        input.focus();
                        return false;
                    }
                    
                    // Return true untuk terus submit (tanpa popup)
                    return true;
                    
                    /* ATAU dengan popup simple:
                    var confirmSave = confirm('Simpan perubahan?');
                    return confirmSave;
                    */
                }
                </script>
            </td>
            <td>
                <a href="uploads/info/<?= $row['filename'] ?>" target="_blank"><?= $row['filename'] ?></a>
            </td>
            <td>
                <a href="?delete=<?= $row['id'] ?>" onclick="return confirm('Padam <?= htmlspecialchars($row['title']) ?>?')">Padam</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
    
    <p><a href="info.php" class="btn-back">← Kembali</a></p>
</main>

<!-- LOAD SWEETALERT DI BAWAH -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
// SweetAlert untuk messages
<?php if(isset($_GET['delete'])): ?>
Swal.fire('Berjaya!', 'Fail dipadam', 'success');
<?php endif; ?>

<?php if(isset($_POST['save'])): ?>
Swal.fire('Berjaya!', 'Tajuk dikemaskini', 'success');
<?php endif; ?>
</script>
</body>
</html>