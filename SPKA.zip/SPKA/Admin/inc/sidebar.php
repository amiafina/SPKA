<script>
        // Log Keluar
      function logoutConfirm(event) {
      event.preventDefault(); // hentikan default link
      Swal.fire({
          title: 'Adakah anda ingin keluar?',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonText: 'Ya',
          cancelButtonText: 'Tidak',
          reverseButtons: true
      }).then((result) => {
          if (result.isConfirmed) {
              // redirect ke page logout
              window.location.href = '../Admin/index.php';
          }
      });
      }

      <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</script>

<aside class="sidebar">
    <h2>SPKA</h2>
    <ul class="sidebar-menu">
      <li class="active">
        <a href="dashboard_admin.php">
            <img src="inc/gambar/dashboard.png" class="icon">
            <span>Papan Muka</span>
        </a>
      </li>
      <li>
        <a href="kehadiran.php">
          <img src="inc/gambar/kehadiran.png" class="icon">
          <span>Kehadiran</span>
        </a>
      </li>
      <li>
        <a href="laporan_bulanan.php">
          <img src="inc/gambar/laporan.png" class="icon">
          <span>Laporan Bulanan</span>
        </a>
      </li>
      <li>
        <a href="info.php">
          <img src="inc/gambar/info.png" class="icon">
          <span>Info</span>
        </a>
      </li>
      <li>
        <a href="maklumat_penghuni.php">
          <img src="inc/gambar/user.png" class="icon">
          <span>Maklumat Penghuni</span>
        </a>
      </li>
      <li>
        <a href="tambah_penghuni">
          <img src="inc/gambar/add.png" class="icon">
          <span>Tambah Penghuni</span>
        </a>
      </li>
      <li>
        <a href="../Admin/index.php" onclick="return logoutConfirm(event)">
          <img src="inc/gambar/logout.png" class="icon">
          <span>Log Keluar</span>
        </a>
      </li>
    </ul>
  </aside>