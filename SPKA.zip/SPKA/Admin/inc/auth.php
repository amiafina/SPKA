<?php
session_start();
include 'connect.php';

$nama_pengguna = $_POST['nama_pengguna'];
$kata_laluan = $_POST['kata_laluan'];

// semak dari database
$query = "SELECT * FROM pengguna WHERE nama_pengguna='$nama_pengguna' AND kata_laluan='$kata_laluan' LIMIT 1";
$result = mysqli_query($conn, $query);

if(mysqli_num_rows($result) == 1){
    $row = mysqli_fetch_assoc($result);
    
    // simpan data user dalam session
    $_SESSION['id_pengguna'] = $row['id_pengguna'];
    $_SESSION['nama_pengguna'] = $row['nama_pengguna'];
    $_SESSION['peranan'] = $row['peranan'];

    // check role & redirect
    if($row['peranan'] == 'admin'){
    header("Location: ../dashboard_admin.php");
    } elseif($row['peranan'] == 'ketua_bilik'){
        header("Location: ../../Pengguna/kehadiran_ketua_bilik.php");
    } elseif($row['peranan'] == 'exco'){
        header("Location: dashboard_exco.php");
    } else {
        echo "<script>alert('Peranan tidak dikenali!'); window.location='index.php';</script>";
    }
    exit();

} else {
    echo "<script>alert('Nama pengguna atau kata laluan salah!'); window.location='inc/index.php';</script>";
}
?>
