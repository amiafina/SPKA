<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "spka"; // nama database Fina

$conn = mysqli_connect($servername, $username, $password, $database);

if (!$conn) {
    die("Sambungan gagal: " . mysqli_connect_error());
}
?>
