<?php
// Sambungan ke database
$conn = new mysqli('localhost','root','','spka');
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
$conn->set_charset("utf8mb4");

// Ambil data dari form
$nama_penghuni = $_POST['nama_penghuni'] ?? '';
$nama_bilik = $_POST['nama_bilik'] ?? '';
$kelas = $_POST['kelas'] ?? '';
$no_tel = $_POST['no_tel'] ?? '';
$nama_ibu = $_POST['nama_ibu'] ?? '';
$no_tel_ibu = $_POST['no_tel_ibu'] ?? '';
$nama_jbu = $_POST['nama_jbu'] ?? '';
$no_tel_jbu = $_POST['no_tel_jbu'] ?? '';
$nama_bapa = $_POST['nama_bapa'] ?? '';
$no_tel_bapa = $_POST['no_tel_bapa'] ?? '';
$alamat = $_POST['alamat'] ?? '';

// Prepare & bind
$sql = "INSERT INTO penghuni 
(nama_penghuni,nama_bilik,kelas,no_tel,nama_ibu,no_tel_ibu,nama_bapa,no_tel_bapa,alamat)
VALUES (?,?,?,?,?,?,?,?,?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssssssss",$nama_penghuni,$nama_bilik,$kelas,$no_tel,$nama_ibu,$no_tel_ibu,$nama_bapa,$no_tel_bapa,$alamat);

// Execute
if($stmt->execute()){
    header("Location: tambah_penghuni.php?success=1");
    exit();
}else{
    echo "Error: ".$stmt->error;
}

$stmt->close();
$conn->close();
?>
