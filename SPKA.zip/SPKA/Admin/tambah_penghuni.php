<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tambah Penghuni</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/style_sidebar.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
<style>
body.dashboard-page { display: flex; }
.sidebar { width:220px; position: fixed; top:0; left:0; height:100vh; background:#2c3e50; color:white; padding:20px; overflow-y:auto;}
.sidebar h2{color:#fff; text-align:center; margin-bottom:30px;}
.sidebar-menu{list-style:none; padding:0;}
.sidebar-menu li{margin-bottom:15px;}
.sidebar-menu li a{color:white; text-decoration:none; display:flex; align-items:center;}
.sidebar-menu li a .icon{width:24px; margin-right:10px;}
.sidebar-menu li.active a{font-weight:bold;}
.main-content { margin-left:240px; padding:20px; width:100%; }
</style>
</head>
<body class="dashboard-page">

<aside class="sidebar">
<h2>SPKA</h2>
<ul class="sidebar-menu">
<li><a href="dashboard_admin.php"><img src="inc/gambar/dashboard.png" class="icon"><span>Papan Muka</span></a></li>
<li><a href="kehadiran.php"><img src="inc/gambar/kehadiran.png" class="icon"><span>Kehadiran</span></a></li>
<li><a href="laporan_bulanan.php"><img src="inc/gambar/laporan.png" class="icon"><span>Laporan Bulanan</span></a></li>
<li><a href="info.php"><img src="inc/gambar/info.png" class="icon"><span>Info</span></a></li>
<li><a href="maklumat_penghuni.php"><img src="inc/gambar/user.png" class="icon"><span>Maklumat Penghuni</span></a></li>
<li class="active"><a href="tambah_penghuni.php"><img src="inc/gambar/add.png" class="icon"><span>Tambah Penghuni</span></a></li>
<br><br>
<li><a href="index.php" onclick="return logoutConfirm(event)"><img src="inc/gambar/logout.png" class="icon"><span>Log Keluar</span></a></li>
</ul>
</aside>

<div class="main-content">
<div class="container-fluid mt-5">
<h2 class="mb-4">📝 Tambah Penghuni Baru</h2>

<?php if(isset($_GET['success'])): ?>
<div class="alert alert-success">Penghuni berjaya ditambah!</div>
<?php endif; ?>

<form action="proses_tambah.php" method="POST">
<div class="row">
<div class="col-md-6">
<div class="card mb-4">
<div class="card-header bg-primary text-white"><h5>Maklumat Penghuni</h5></div>
<div class="card-body">
<div class="mb-3">
<label class="form-label">Nama Penghuni <span class="text-danger">*</span></label>
<input type="text" class="form-control" name="nama_penghuni" required>
</div>
<div class="row">
<div class="col-md-6 mb-3">
<label class="form-label">Nama Bilik</label>
<input type="text" class="form-control" name="nama_bilik">
</div>
<div class="col-md-6 mb-3">
<label class="form-label">Kelas</label>
<input type="text" class="form-control" name="kelas">
</div>
</div>
<div class="mb-3">
<label class="form-label">No. Telefon Penghuni</label>
<input type="tel" class="form-control" name="no_tel">
</div>
<div class="mb-3">
<label class="form-label">Alamat</label>
<textarea class="form-control" name="alamat" rows="3"></textarea>
</div>
</div>
</div>
</div>

<div class="col-md-6">
<div class="card mb-4">
<div class="card-header bg-success text-white"><h5>Maklumat Penjaga</h5></div>
<div class="card-body">
<div class="mb-3">
<label class="form-label">Nama Ibu</label>
<input type="text" class="form-control" name="nama_jbu">
</div>
<div class="mb-3">
<label class="form-label">No. Telefon Ibu</label>
<input type="tel" class="form-control" name="no_tel_jbu">
</div>
<hr>
<div class="mb-3">
<label class="form-label">Nama Bapa</label>
<input type="text" class="form-control" name="nama_bapa">
</div>
<div class="mb-3">
<label class="form-label">No. Telefon Bapa</label>
<input type="tel" class="form-control" name="no_tel_bapa">
</div>
</div>
</div>
</div>
</div>

<div class="d-flex gap-2">
<button type="submit" class="btn btn-success"><i class="bi bi-save"></i> Simpan</button>
<button type="reset" class="btn btn-outline-danger"><i class="bi bi-eraser"></i> Set Semula</button>
</div>
</form>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function logoutConfirm(event){if(!confirm('Adakah anda pasti mahu log keluar?')){event.preventDefault(); return false;}}
</script>

</body>
</html>
