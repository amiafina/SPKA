<?php
include 'inc/connect.php';

// ----- PROSES UPLOAD FAIL -----
$msg = "";

if(isset($_POST['upload'])){
    $title = $_POST['title'];
    $fileName = $_FILES['file']['name'];
    $tmp = $_FILES['file']['tmp_name'];

    if(!is_dir("uploads/info")){
        mkdir("uploads/info", 0777, true);
    }

    $path = "uploads/info/" . $fileName;
    move_uploaded_file($tmp, $path);

    mysqli_query($conn, "INSERT INTO info_files(title, filename) VALUES('$title', '$fileName')");

    $msg = "Fail berjaya diupload!";
}
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <title>Info</title>
    <link rel="stylesheet" href="css/style_sidebar.css">
    <link rel="stylesheet" href="css/style_laporan.css">
    <link rel="stylesheet" href="css/style_info.css">
    <!-- TAMBAH SWEETALERT2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
</head>

<body>

<!-- SIDEBAR -->
<aside class="sidebar">
    <h2>SPKA</h2>
    <ul class="sidebar-menu">
        <li><a href="dashboard_admin.php"><img src="inc/gambar/dashboard.png" class="icon"><span>Papan Muka</span></a></li>
        <li><a href="kehadiran.php"><img src="inc/gambar/kehadiran.png" class="icon"><span>Kehadiran</span></a></li>
        <li><a href="laporan_bulanan.php"><img src="inc/gambar/laporan.png" class="icon"><span>Laporan Bulanan</span></a></li>

        <li class="active"><a href="info.php"><img src="inc/gambar/info.png" class="icon"><span>Info</span></a></li>

        <li><a href="maklumat_penghuni.php"><img src="inc/gambar/user.png" class="icon"><span>Maklumat Penghuni</span></a></li>
        <li><a href="tambah_penghuni.php"><img src="inc/gambar/add.png" class="icon"><span>Tambah Penghuni</span></a></li>

        <br><br>
        <li>
            <a href="index.php" onclick="return logoutConfirm(event)">
                <img src="inc/gambar/logout.png" class="icon"><span>Log Keluar</span>
            </a>
        </li>
    </ul>
</aside>

<!-- MAIN CONTENT -->
<main class="content">

    <h1>Muat Naik Info</h1>

    <!-- Papar message -->
    <?php if($msg != ""): ?>
        <p style="color:green; font-weight:bold;"><?= $msg ?></p>
    <?php endif; ?>

    <!-- BORANG UPLOAD -->
    <form method="post" enctype="multipart/form-data" class="upload-form">
        <label>Tajuk:</label>
        <input type="text" name="title" required>

        <label>Fail:</label>
        <input type="file" name="file" required>

        <button type="submit" name="upload">Muat Naik</button>
    </form>

    <br>
    <a href="info_list.php" class="btn-view">Lihat Senarai Info</a>

</main>

<!-- TAMBAH SWEETALERT2 JS -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
// Function untuk logout confirmation
function logoutConfirm(event) {
    event.preventDefault();
    
    Swal.fire({
        title: 'Log Keluar?',
        text: 'Adakah anda pasti ingin log keluar dari sistem?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Ya, Log Keluar',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'index.php';
        }
    });
    
    return false;
}

// Alert untuk success upload
<?php if($msg != ""): ?>
document.addEventListener('DOMContentLoaded', function() {
    Swal.fire({
        icon: 'success',
        title: 'Berjaya!',
        text: '<?= $msg ?>',
        confirmButtonText: 'OK',
        confirmButtonColor: '#3085d6',
        timer: 3000,
        timerProgressBar: true
    });
});
<?php endif; ?>

// Validation untuk form upload (optional)
document.querySelector('.upload-form').addEventListener('submit', function(e) {
    var title = this.querySelector('input[name="title"]').value.trim();
    var file = this.querySelector('input[name="file"]').value;
    
    if(title === '') {
        e.preventDefault();
        Swal.fire({
            icon: 'warning',
            title: 'Tajuk Kosong',
            text: 'Sila masukkan tajuk maklumat',
            confirmButtonText: 'OK',
            confirmButtonColor: '#f39c12'
        });
        return false;
    }
    
    if(file === '') {
        e.preventDefault();
        Swal.fire({
            icon: 'warning',
            title: 'Fail Tidak Dipilih',
            text: 'Sila pilih fail untuk dimuat naik',
            confirmButtonText: 'OK',
            confirmButtonColor: '#f39c12'
        });
        return false;
    }
    
    // Show loading
    Swal.fire({
        title: 'Sedang Memuat Naik...',
        html: 'Sila tunggu sebentar',
        allowOutsideClick: false,
        showConfirmButton: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
    
    return true;
});
</script>
</body>
</html>