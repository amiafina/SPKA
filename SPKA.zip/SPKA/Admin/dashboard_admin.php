<?php
session_start();
include 'inc/connect.php';
date_default_timezone_set('Asia/Kuala_Lumpur');

// === FUNCTIONS ===
function getHadir($conn, $roomName) {
    $today = date('Y-m-d');
    
    // AUTO RESET selepas 10 malam
    if (date('H') >= 22) {
        $conn->query("UPDATE kehadiran SET status='TIDAK_HADIR' WHERE tarikh > CURDATE()");
    }
    
    $query = "SELECT k.status 
              FROM kehadiran k
              JOIN penghuni p ON k.id_penghuni = p.id_penghuni
              WHERE LOWER(p.nama_bilik) = LOWER('$roomName') AND k.tarikh = '$today'";
    $result = $conn->query($query);

    $hadir = 0;
    $tidak = 0;
    
    while($row = $result->fetch_assoc()){
        // CHECK STRING 'HADIR' bukan integer 1
        if(strtoupper(trim($row['status'])) === 'HADIR') {
            $hadir++;
        } else {
            $tidak++;
        }
    }
    
    return ['hadir' => $hadir, 'tidak' => $tidak];
}

function getHadirBlock($conn, $blockName, $bilikPerBlock=8){
    $hadir=0; $tidak=0;
    for($i=1;$i<=$bilikPerBlock;$i++){
        $roomName = "$blockName $i";
        $data = getHadir($conn, $roomName);
        $hadir += $data['hadir'];
        $tidak += $data['tidak'];
    }
    return ['hadir'=>$hadir,'tidak'=>$tidak];
}

// === DATA ===
$bilikPerBlock = 8; // bilik per blok
$blocks = ['ABU BAKAR','UMAR','SITI KHADIJAH','SITI AISYAH','SITI HAJAR'];
$aspuraBlocks = ['ABU BAKAR','UMAR'];
$aspuriBlocks = ['SITI KHADIJAH','SITI AISYAH','SITI HAJAR'];

// Jumlah keseluruhan
$totalAspura = ['hadir'=>0,'tidak'=>0];
$totalAspuri = ['hadir'=>0,'tidak'=>0];
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin SPKA</title>
    <link rel="stylesheet" href="css/style_dashboard.css">
    <link rel="stylesheet" href="css/style_sidebar.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="dashboard-page">

<aside class="sidebar">
  <?php include 'inc/sidebar.php'; ?>
</aside>

<main class="content">
<header class="header">
    <div>
      <h1>SISTEM PENGURUSAN KEHADIRAN ASRAMA (SPKA)</h1>
      <h4>Selamat Datang, Admin.</h4><br>
    </div>
    <span id="currentDateTime"></span>

<script>
function updateDateTime() {
    const options = { 
        weekday:'long', day:'numeric', month:'long', year:'numeric',
        hour:'2-digit', minute:'2-digit', second:'2-digit', hour12:false,
        timeZone:'Asia/Kuala_Lumpur' 
    };
    document.getElementById('currentDateTime').textContent = 
        new Date().toLocaleString('ms-MY', options);
}
setInterval(updateDateTime, 1000);
updateDateTime();

function logoutConfirm(event) {
    event.preventDefault();
    Swal.fire({
      title: 'Adakah anda ingin keluar?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Ya',
      cancelButtonText: 'Tidak',
      reverseButtons: true
    }).then((result) => {
        if(result.isConfirmed){
            window.location.href='../Admin/index.php';
        }
    });
}
</script>
</header>

<!-- TABLE PER BILIK -->
<h3 style="text-align:center">STATISTIK PENGHUNI ASRAMA</h3>
<table class="attendance-table">
    <thead>
        <tr>
            <th>BILIK</th>
            <?php for($i=1;$i<=$bilikPerBlock;$i++): ?>
            <th><?= $i ?></th>
            <?php endfor; ?>
        </tr>
    </thead>
    <tbody>
        <?php foreach($blocks as $block): ?>
        <tr>
            <td><?= $block ?></td>
            <?php for($i=1;$i<=$bilikPerBlock;$i++):
                $roomName = "$block $i";
                $data = getHadir($conn,$roomName);
            ?>
            <td><?= $data['hadir'].' / '.($data['hadir']+$data['tidak']) ?></td>
            <?php endfor; ?>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<!-- CARDS PER BLOK -->
<div class="cards-row">
<section class="cards">
    <!-- ASPURA CARDS -->
    <?php 
    foreach($aspuraBlocks as $block){
        $data = getHadirBlock($conn,$block,$bilikPerBlock);
        $totalAspura['hadir'] += $data['hadir'];
        $totalAspura['tidak'] += $data['tidak'];
    ?>
    <div class="card biru">
        <h3><?= $block ?></h3>
        <p><strong><?= $data['hadir'] ?></strong> Hadir</p>
        <p><strong><?= $data['tidak'] ?></strong> Tidak Hadir</p>
    </div>
    <?php } ?>
    <div class="card biru aspura">
        <h3>JUMLAH ASPURA</h3>
        <p><strong><?= $totalAspura['hadir'].' / '.($totalAspura['hadir']+$totalAspura['tidak']) ?></strong></p>
    </div>

    <!-- ASPURI CARDS -->
    <?php 
    foreach($aspuriBlocks as $block){
        $data = getHadirBlock($conn,$block,$bilikPerBlock);
        $totalAspuri['hadir'] += $data['hadir'];
        $totalAspuri['tidak'] += $data['tidak'];
    ?>
    <div class="card pink">
        <h3><?= $block ?></h3>
        <p><strong><?= $data['hadir'] ?></strong> Hadir</p>
        <p><strong><?= $data['tidak'] ?></strong> Tidak Hadir</p>
    </div>
    <?php } ?>
    <div class="card pink aspuri">
        <h3>JUMLAH ASPURI</h3>
        <p><strong><?= $totalAspuri['hadir'].' / '.($totalAspuri['hadir']+$totalAspuri['tidak']) ?></strong></p>
    </div>

    <!-- JUMLAH KESELURUHAN -->
    <div class="card oren">
        <h3>JUMLAH KESELURUHAN</h3>
        <p><strong><?= ($totalAspura['hadir']+$totalAspuri['hadir']).' / '.($totalAspura['hadir']+$totalAspura['tidak']+$totalAspuri['hadir']+$totalAspuri['tidak']) ?></strong></p>
    </div>
</section>
</div>

<br>
<div class="footer">
    <b><p>© 2025 SPKA | SISTEM PENGURUSAN KEHADIRAN ASRAMA</p></b>       
</div>

</main>
</body>
</html>
