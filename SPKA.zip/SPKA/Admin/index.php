<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="css/style_login.css">
    <title>SPKA Log Masuk</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body class="index-page">
    <img src="inc/gambar/logokvks.jpg" class="logokvks"> 
    <img src="inc/gambar/kokedi.png" class="kokedi">
    <h1>SPKA</h1>
    <h2>SISTEM PENGURUSAN KEHADIRAN ASRAMA</h2>

    <div class="login-box">
        <form action="inc/auth.php" method="POST">
            <?php
            include 'inc/connect.php'; // sambungan DB
            function e($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

            // Dapatkan semua pengguna
            $res = $conn->query("SELECT id_pengguna, nama_pengguna FROM pengguna ORDER BY nama_pengguna ASC");
            ?>
            
            <label for="nama_pengguna"></label>
            <select name="nama_pengguna" id="nama_pengguna" required>
                <option value="">Nama Pengguna</option>
                <?php while($row = $res->fetch_assoc()): ?>
                    <option value="<?= e($row['nama_pengguna']) ?>"><?= e($row['nama_pengguna']) ?></option>
                <?php endwhile; ?>
            </select>

            <input type="password" name="kata_laluan" placeholder="Kata Laluan" required>
            <button type="submit">Log Masuk</button>
            <br>
            <br>
            <marquee behavior="scroll" direction="left">
                 Sekiranya terlupa kata laluan, sila hubungi ketua warden.
            </marquee>
        </form>
    </div>
</body>
</html>
