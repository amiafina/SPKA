<?php
session_start();
include 'connect.php';

if(!isset($_SESSION['id_pengguna']) || $_SESSION['peranan'] != 'ketua_bilik'){
    header("Location: index.php");
    exit();
}

$bilik = $_POST['bilik'];
$tarikh = $_POST['tarikh'];
$hadir = $_POST['hadir']; // array id_pelajar => 'Y'
$catatan = $_POST['catatan'];
$lain = $_POST['lain'];

foreach($catatan as $id_pelajar => $c){
    $catatan_akhir = ($c == 'Lain-lain') ? mysqli_real_escape_string($conn, $lain[$id_pelajar]) : $c;
    $status_hadir = isset($hadir[$id_pelajar]) ? 'Y' : 'N';

    // simpan ke table kehadiran
    $query = "INSERT INTO kehadiran (id_pelajar, tarikh, hadir, catatan)
              VALUES ('$id_pelajar', '$tarikh', '$status_hadir', '$catatan_akhir')";
    mysqli_query($conn, $query);
}

echo "<script>alert('Kehadiran berjaya disimpan!'); window.location='dashboard_ketua.php';</script>";
?>
