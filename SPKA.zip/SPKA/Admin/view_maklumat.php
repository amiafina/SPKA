<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "spka";

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) die("Sambungan gagal: " . $conn->connect_error);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$penghuni = null;
if ($id) {
    $res = $conn->query("
        SELECT p.*, b.nama_bilik
        FROM penghuni p
        LEFT JOIN bilik b ON p.bilik = b.id
        WHERE p.id_penghuni = $id
    ");
    $penghuni = $res->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Maklumat Penuh Penghuni</title>
<link rel="stylesheet" href="style_sidebar.css">
<style>
.content { margin-left: 220px; padding: 20px; }
table { width: 50%; border-collapse: collapse; background: #fff; }
th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
button { padding: 5px 10px; border-radius: 4px; border: none; background-color: #3498db; color: white; cursor: pointer; margin-top: 10px; }
button:hover { background-color: #2980b9; }
</style>
</head>
<body class="dashboard-page">

<aside class="sidebar">
  <h2>SPKA</h2>
  <ul>
    <li><a href="dashboard_admin.php">Papan Muka</a></li>
    <li>Kehadiran</li>
    <li>Laporan Kehadiran</li>
    <li>Info</li>
    <li><a href="maklumat.php" class="active">Maklumat Penghuni</a></li>
    <li>Tambah Penghuni</li>
    <li><a href="index.php">Log Keluar</a></li>
  </ul>
</aside>

<div class="content">
<h1>Maklumat Penuh Penghuni</h1>

<?php if ($penghuni): ?>
<table>
    <tr><td>Nama</td><td><?= $penghuni['nama_penghuni'] ?></td></tr>
    <tr><td>Kelas</td><td><?= $penghuni['kelas'] ?? '' ?></td></tr>
    <tr><td>Bilik</td><td><?= $penghuni['nama_bilik'] ?></td></tr>
    <tr><td>No Telefon</td><td><?= $penghuni['no_tel'] ?? '' ?></td></tr>
    <tr><td>Nama Ibu</td><td><?= $penghuni['ibu'] ?? '' ?></td></tr>
    <tr><td>No Tel Ibu</td><td><?= $penghuni['no_tel_ibu'] ?? '' ?></td></tr>
    <tr><td>Nama Bapa</td><td><?= $penghuni['bapa'] ?? '' ?></td></tr>
    <tr><td>No Tel Bapa</td><td><?= $penghuni['no_tel_bapa'] ?? '' ?></td></tr>
    <tr><td>Alamat</td><td><?= $penghuni['alamat'] ?? '' ?></td></tr>
</table>
<?php else: ?>
<p>Penghuni tidak dijumpai.</p>
<?php endif; ?>

<button onclick="window.location.href='maklumat.php'">Kembali</button>
</div>
</body>
</html>
