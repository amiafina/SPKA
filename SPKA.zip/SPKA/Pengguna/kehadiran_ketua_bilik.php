<?php
session_start();
if(!isset($_SESSION['nama_pengguna']) || $_SESSION['peranan'] != 'ketua_bilik'){
    header("Location: ../Admin/index.php");
    exit();
}

include '../Admin/inc/connect.php';

// Dapatkan nama bilik ikut ketua bilik
$nama_pengguna = $_SESSION['nama_pengguna'];
$query_bilik = mysqli_query($conn, "SELECT nama_bilik FROM pengguna WHERE nama_pengguna='$nama_pengguna' AND peranan='ketua_bilik' LIMIT 1");
$bilik_row = mysqli_fetch_assoc($query_bilik);
$nama_bilik = $bilik_row['nama_bilik'];

// Tarikh hari ini
$tarikh_hari_ini = date('Y-m-d');

// Dapatkan senarai pelajar ikut bilik
$result = mysqli_query($conn, "SELECT id_penghuni, nama_penghuni FROM penghuni WHERE nama_bilik='$nama_bilik'");

// Ambil fail info sentiasa (bukan dari POST)
$info_result = mysqli_query($conn, "SELECT * FROM info_files ORDER BY id DESC");

// Default nilai
$bil_hadir = mysqli_num_rows($result);
$bil_tak_hadir = 0;

// Flag popup
$show_success = false;

// Bila submit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $hadir = isset($_POST['hadir']) ? $_POST['hadir'] : [];

    // Kira bilangan hadir / tak hadir
    $bil_hadir = count($hadir);

    $total_pelajar = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM penghuni WHERE nama_bilik='$nama_bilik'"));
    $bil_tak_hadir = $total_pelajar - $bil_hadir;

    // Simpan rekod
    foreach ($_POST['id_penghuni'] as $id) {
        $status = in_array($id, $hadir) ? 1 : 0;
        $catatan = $_POST['catatan'][$id] ?? '';
        $lain = $_POST['lain'][$id] ?? '';

        if($catatan == 'Lain-lain' && $lain != ''){
            $catatan = $lain;
        }

        mysqli_query($conn, 
            "REPLACE INTO kehadiran (id_penghuni, tarikh, status, catatan)
             VALUES ('$id', CURDATE(), '$status', '$catatan')");
    }

    // trigger popup
    $show_success = true;
}

// Ambil semua kehadiran hari ini untuk bilik
$hadir_today = [];
$check_all = mysqli_query($conn, "SELECT id_penghuni, status, catatan FROM kehadiran WHERE tarikh=CURDATE()");
while($row_check = mysqli_fetch_assoc($check_all)){
    $hadir_today[$row_check['id_penghuni']] = $row_check;
}

?>

<!DOCTYPE html>
<html lang="ms">
<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<meta charset="UTF-8">
<title>Kehadiran</title>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="../Admin/css/style_sidebar.css">
<style>
    table, th, td { border: 1px solid #000; border-collapse: collapse; }
    th, td { padding: 8px; text-align: center; }
    select, input[type=text] { padding: 4px; }
    .form-group { margin-bottom: 10px; }

    #bilik {
        border: none !important;
        background: transparent !important;
        outline: none !important;
        box-shadow: none !important;
        padding: 0;
        font-size: 25px;
        font-weight: bold;
        text-transform: uppercase;
    }

    /* Popup style */
    .modal {
        display: none;
        position: fixed;
        z-index: 9999;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0,0,0,0.5);
    }
    .modal-content {
        background: #fff;
        margin: 10% auto;
        padding: 20px;
        border-radius: 10px;
        width: 70%;
        max-width: 500px;
        box-shadow: 0px 0px 10px rgba(0,0,0,0.3);
        text-align: center;
    }
    .close {
        float: right;
        font-size: 24px;
        cursor: pointer;
    }
    a.download-link { color: #007bff; text-decoration: none; }
    a.download-link:hover { text-decoration: underline; }
</style>

<!-- Load SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body class="dashboard-page">
  <!-- Sidebar -->
  <aside class="sidebar">
    <h2>SPKA</h2>
    <ul>
      <li class="active">
        <a href="kehadiran_ketua_bilik.php">
          <img src="../admin/inc/gambar/kehadiran.png" class="icon">
          <span>Kehadiran</span>
        </a>
      </li>
      <li><a href="#" id="btnInfo">
        <img src="../admin/inc/gambar/info.png" class="icon">Info</a></li>
      <li>
        <a href="../Admin/index.php" onclick="logoutConfirm(event)">
            <img src="../admin/inc/gambar/logout.png" class="icon">
            <span>Log Keluar</span>
        </a>
      </li>
    </ul>
  </aside>

  <!-- Content -->
  <main class="content">
    <form method="POST" id="formKehadiran">
      <div class="form-group">
        <input type="text" id="bilik" value="<?php echo $nama_bilik; ?>" readonly>
      </div>

      <div class="form-group">
        <label for="tarikh">TARIKH:</label>
        <input type="date" name="tarikh" max="<?php echo $tarikh_hari_ini; ?>" value="<?php echo $tarikh_hari_ini; ?>" readonly>
      </div>
      
      <hr>
      <div class="form-group">
        <label>BIL. HADIR: </label>
        <input type="text" value="<?= $bil_hadir ?>" readonly>
      </div>

      <div class="form-group">
        <label>BIL. TIDAK HADIR: </label>
        <input type="text" value="<?= $bil_tak_hadir ?>" readonly>
      </div>

      <div class="table-content">
      <table>
        <thead>
          <tr>
            <th>BIL.</th>
            <th>KEHADIRAN</th>
            <th>NAMA PELAJAR</th>
            <th>CATATAN</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $i=1;
          mysqli_data_seek($result, 0);
          while($row = mysqli_fetch_assoc($result)) {
              $hadir_status = $hadir_today[$row['id_penghuni']] ?? null;

              if(!$hadir_status){
                  $checked = "checked";
                  $catatan_simpan = '';
              } else {
                  $checked = ($hadir_status['status'] == 1) ? "checked" : "";
                  $catatan_simpan = $hadir_status['catatan'];
              }
          ?>
          <tr>
            <td><?php echo $i++; ?></td>
            <td><input type="checkbox" name="hadir[]" value="<?php echo $row['id_penghuni']; ?>" <?php echo $checked; ?>></td>
            <td><?php echo $row['nama_penghuni']; ?></td>
            <td style="width:200px;">
                      <select name="catatan[<?php echo $row['id_penghuni']; ?>]" 
                              class="catatanSelect" 
                              style="width: 100%; margin-bottom: 5px;">
                          <option value="" <?php if($catatan_simpan=="") echo "selected"; ?>>Sila pilih</option>
                          <option value="Sakit" <?php if($catatan_simpan=="Sakit") echo "selected"; ?>>Sakit</option>
                          <option value="Balik kampung" <?php if($catatan_simpan=="Balik kampung") echo "selected"; ?>>Balik kampung</option>
                          <option value="Lain-lain" <?php if($catatan_simpan!="" && $catatan_simpan!="Sakit" && $catatan_simpan!="Balik kampung") echo "selected"; ?>>Lain-lain</option>
                      </select>
                      
                      <input type="text" 
                            name="lain[<?php echo $row['id_penghuni']; ?>]" 
                            class="lainInput" 
                            value="<?php echo ($catatan_simpan!="" && $catatan_simpan!="Sakit" && $catatan_simpan!="Balik kampung") ? $catatan_simpan : ''; ?>"
                            style="width: 100%; 
                                    <?php echo ($catatan_simpan!="" && $catatan_simpan!="Sakit" && $catatan_simpan!="Balik kampung") ? 'display:block;' : 'display:none;'; ?>" 
                            placeholder="Sila taip">
                  
              </td>
          </tr>
          <input type="hidden" name="id_penghuni[]" value="<?php echo $row['id_penghuni']; ?>">
          <?php } ?>
        </tbody>
      </table>
        </div>

      <div style="display: flex; justify-content: flex-end; margin-top: 10px;">
        <button type="submit" style="width: 100px;">HANTAR</button>
      </div>
    </form>
  </main>

  <!-- POPUP INFO -->
  <div id="infoModal" class="modal">
    <div class="modal-content">
      <span class="close" id="closeModal">&times;</span>
      <h3>Info Kolej Kediaman</h3>
      <table style="width:500px;">
        <thead>
          <tr>
            <th>BIL</th>
            <th style="width:500px;">TAJUK FAIL</th>
            <th style="width:300px;">MUAT TURUN</th>
          </tr>
        </thead>
        <tbody>
          <?php 
          $i = 1;
          while($info = mysqli_fetch_assoc($info_result)) { ?>
            <tr>
              <td><?= $i++; ?></td>
              <td><?= $info['title']; ?></td>
              <td style="text-align:center;">
                <a class="download-link" href="../Admin/uploads/info/<?= $info['filename']; ?>" target="_blank">
                  Lihat / Muat Turun 📥
                </a>
              </td>
            </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- JAVA SCRIPT -->

<script>
// show/hide input “Lain-lain”
document.querySelectorAll('.catatanSelect').forEach(function(select){
    select.addEventListener('change', function(){
        let inputLain = this.nextElementSibling;
        if(this.value == 'Lain-lain'){
            inputLain.style.display = 'inline';
        } else {
            inputLain.style.display = 'none';
            inputLain.value = '';
        }
    });
});

// popup info
const modal = document.getElementById('infoModal');
const btn = document.getElementById('btnInfo');
const span = document.getElementById('closeModal');
btn.onclick = (e) => { e.preventDefault(); modal.style.display = 'block'; };
span.onclick = () => modal.style.display = 'none';
window.onclick = e => { if (e.target == modal) modal.style.display = 'none'; };

// VALIDATION: TIDAK HADIR WAJIB SEBAB


// LOGOUT SWEETALERT2
function logoutConfirm(event) {
    event.preventDefault();
    Swal.fire({
        title: 'Adakah anda ingin keluar?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya',
        cancelButtonText: 'Tidak',
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = '../Admin/index.php';
        }
    });
}

// VALIDATION: TIDAK HADIR WAJIB SEBAB
document.getElementById('formKehadiran').addEventListener('submit', function(e){
    let prevent = false;
    document.querySelectorAll('tbody tr').forEach(function(row){
        let checkbox = row.querySelector('input[type="checkbox"]');
        let select = row.querySelector('select');
        let inputLain = row.querySelector('input.lainInput');

        if(checkbox && !checkbox.checked){
            if(select && select.value == ''){
                // SweetAlert2 menggantikan alert()
                Swal.fire({
                    title: 'Peringatan!',
                    text: 'Sila pilih sebab bagi yang tidak hadir.',
                    icon: 'warning',
                    confirmButtonText: 'OK',
                    timer: 3000,
                    timerProgressBar: true,
                });
                select.focus();
                prevent = true;
                e.preventDefault();
                return false;
            }
            if(select && select.value == 'Lain-lain' && inputLain.value.trim() == ''){
                Swal.fire({
                    title: 'Peringatan!',
                    text: 'Sila nyatakan sebab bagi yang tidak hadir.',
                    icon: 'warning',
                    confirmButtonText: 'OK',
                    timer: 3000,
                    timerProgressBar: true,
                });
                inputLain.focus();
                prevent = true;
                e.preventDefault();
                return false;
            }
        }
    });
    if(prevent) e.preventDefault();
});


// POP UP BERJAYA
<?php if($show_success): ?>
Swal.fire({
    title: 'Berjaya!',
    text: 'Rekod berjaya dihantar.',
    icon: 'success',
    confirmButtonText: 'OK',
    timer: 2500,
    timerProgressBar: true,
});
<?php endif; ?>
</script>
</body>
</html>
