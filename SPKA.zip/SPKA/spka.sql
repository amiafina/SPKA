-- phpMyAdmin SQL Dump
-- version 5.3.0-dev+20230109.7cde53ed0d
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2025 at 10:33 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spka`
--

-- --------------------------------------------------------

--
-- Table structure for table `bilik`
--

CREATE TABLE `bilik` (
  `id` int(11) NOT NULL,
  `nama_bilik` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bilik`
--

INSERT INTO `bilik` (`id`, `nama_bilik`) VALUES
(1, 'Abu Bakar 1'),
(2, 'Abu Bakar 2'),
(3, 'Abu Bakar 3'),
(4, 'Abu Bakar 4'),
(5, 'Abu Bakar 5'),
(6, 'Abu Bakar 6'),
(7, 'Abu Bakar 7'),
(8, 'Abu Bakar 8'),
(9, 'Umar 1'),
(10, 'Umar 2'),
(11, 'Umar 3'),
(12, 'Umar 4'),
(13, 'Umar 5'),
(14, 'Umar 6'),
(15, 'Umar 7'),
(16, 'Umar 8'),
(17, 'Siti Khadijah 1'),
(18, 'Siti Khadijah 2'),
(19, 'Siti Khadijah 3'),
(20, 'Siti Khadijah 4'),
(21, 'Siti Khadijah 5'),
(22, 'Siti Khadijah 6'),
(23, 'Siti Khadijah 7'),
(24, 'Siti Khadijah 8'),
(25, 'Siti Aisyah 1'),
(26, 'Siti Aisyah 2'),
(27, 'Siti Aisyah 3'),
(28, 'Siti Aisyah 4'),
(29, 'Siti Aisyah 5'),
(30, 'Siti Aisyah 6'),
(31, 'Siti Aisyah 7'),
(32, 'Siti Aisyah 8'),
(33, 'Siti Hajar 1'),
(34, 'Siti Hajar 2'),
(35, 'Siti Hajar 3'),
(36, 'Siti Hajar 4'),
(37, 'Siti Hajar 5'),
(38, 'Siti Hajar 6'),
(39, 'Siti Hajar 7'),
(40, 'Siti Hajar 8');

-- --------------------------------------------------------

--
-- Table structure for table `info_files`
--

CREATE TABLE `info_files` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `uploaded_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `info_files`
--

INSERT INTO `info_files` (`id`, `title`, `filename`, `uploaded_at`) VALUES
(1, 'Jadual Pulang Bermalam 2025', 'Tanda tangan Ami.pdf', '2025-11-27 09:42:08');

-- --------------------------------------------------------

--
-- Table structure for table `kehadiran`
--

CREATE TABLE `kehadiran` (
  `id_penghuni` int(11) NOT NULL,
  `tarikh` date NOT NULL,
  `status` enum('Hadir','Tidak Hadir') DEFAULT 'Hadir',
  `catatan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `id_pengguna` int(11) NOT NULL,
  `nama_pengguna` varchar(100) NOT NULL,
  `kata_laluan` varchar(100) NOT NULL,
  `peranan` enum('admin','ketua_bilik','exco') NOT NULL,
  `nama_bilik` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `nama_pengguna`, `kata_laluan`, `peranan`, `nama_bilik`) VALUES
(1, 'Admin', '@dm1n', 'admin', NULL),
(2, 'Exco', 'Ex_Co', 'exco', NULL),
(3, 'Abu Bakar 1', 'A3u3akar1', 'ketua_bilik', 'Abu Bakar 1'),
(4, 'Abu Bakar 2', 'A3u_3akar2', 'ketua_bilik', 'Abu Bakar 2'),
(5, 'Abu Bakar 3', 'abu3123', 'ketua_bilik', 'Abu Bakar 3'),
(6, 'Abu Bakar 4', 'abu4123', 'ketua_bilik', 'Abu Bakar 4'),
(7, 'Abu Bakar 5', 'abu5123', 'ketua_bilik', 'Abu Bakar 5'),
(8, 'Abu Bakar 6', 'abu6123', 'ketua_bilik', 'Abu Bakar 6'),
(9, 'Abu Bakar 7', 'abu7123', 'ketua_bilik', 'Abu Bakar 7'),
(10, 'Abu Bakar 8', 'abu8123', 'ketua_bilik', 'Abu Bakar 8'),
(11, 'Umar 1', 'umar1123', 'ketua_bilik', 'Umar 1'),
(12, 'Umar 2', 'umar2123', 'ketua_bilik', 'Umar 2'),
(13, 'Umar 3', 'umar3123', 'ketua_bilik', 'Umar 3'),
(14, 'Umar 4', 'umar4123', 'ketua_bilik', 'Umar 4'),
(15, 'Umar 5', 'umar5123', 'ketua_bilik', 'Umar 5'),
(16, 'Umar 6', 'umar6123', 'ketua_bilik', 'Umar 6'),
(17, 'Umar 7', 'umar7123', 'ketua_bilik', 'Umar 7'),
(18, 'Umar 8', 'umar8123', 'ketua_bilik', 'Umar 8'),
(19, 'Siti Khadijah 1', 'SK4821', 'ketua_bilik', 'Siti Khadijah 1'),
(20, 'Siti Khadijah 2', 'SK9375', 'ketua_bilik', 'Siti Khadijah 2'),
(21, 'Siti Khadijah 3', 'SK6142', 'ketua_bilik', 'Siti Khadijah 3'),
(22, 'Siti Khadijah 4', 'SK7593', 'ketua_bilik', 'Siti Khadijah 4'),
(23, 'Siti Khadijah 5', 'SK3284', 'ketua_bilik', 'Siti Khadijah 5'),
(24, 'Siti Khadijah 6', 'SK8461', 'ketua_bilik', 'Siti Khadijah 6'),
(25, 'Siti Khadijah 7', 'SK2957', 'ketua_bilik', 'Siti Khadijah 7'),
(26, 'Siti Khadijah 8', 'SK1038', 'ketua_bilik', 'Siti Khadijah 8'),
(27, 'Siti Hajar 1', 'SH3947', 'ketua_bilik', 'Siti Hajar 1'),
(28, 'Siti Hajar 2', 'SH5820', 'ketua_bilik', 'Siti Hajar 2'),
(29, 'Siti Hajar 3', 'SH7104', 'ketua_bilik', 'Siti Hajar 3'),
(30, 'Siti Hajar 4', 'SH8692', 'ketua_bilik', 'Siti Hajar 4'),
(31, 'Siti Hajar 5', 'SH4316', 'ketua_bilik', 'Siti Hajar 5'),
(32, 'Siti Hajar 6', 'SH2975', 'ketua_bilik', 'Siti Hajar 6'),
(33, 'Siti Hajar 7', 'SH6083', 'ketua_bilik', 'Siti Hajar 7'),
(34, 'Siti Hajar 8', 'SH7541', 'ketua_bilik', 'Siti Hajar 8'),
(35, 'Siti Aisyah 1', 'SA9283', 'ketua_bilik', 'Siti Aisyah 1'),
(36, 'Siti Aisyah 2', 'SA3741', 'ketua_bilik', 'Siti Aisyah 2'),
(37, 'Siti Aisyah 3', 'SA6158', 'ketua_bilik', 'Siti Aisyah 3'),
(38, 'Siti Aisyah 4', 'SA4802', 'ketua_bilik', 'Siti Aisyah 4'),
(39, 'Siti Aisyah 5', 'SA7926', 'ketua_bilik', 'Siti Aisyah 5'),
(40, 'Siti Aisyah 6', 'SA1583', 'ketua_bilik', 'Siti Aisyah 6'),
(41, 'Siti Aisyah 7', 'SA6347', 'ketua_bilik', 'Siti Aisyah 7'),
(42, 'Siti Aisyah 8', 'SA5092', 'ketua_bilik', 'Siti Aisyah 8');

-- --------------------------------------------------------

--
-- Table structure for table `penghuni`
--

CREATE TABLE `penghuni` (
  `id_penghuni` int(11) NOT NULL,
  `nama_penghuni` varchar(100) DEFAULT NULL,
  `nama_bilik` varchar(50) DEFAULT NULL,
  `kelas` varchar(50) DEFAULT NULL,
  `no_tel` varchar(20) DEFAULT NULL,
  `nama_ibu` varchar(100) DEFAULT NULL,
  `no_tel_ibu` varchar(20) DEFAULT NULL,
  `nama_bapa` varchar(100) DEFAULT NULL,
  `no_tel_bapa` varchar(20) DEFAULT NULL,
  `alamat` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `penghuni`
--

INSERT INTO `penghuni` (`id_penghuni`, `nama_penghuni`, `nama_bilik`, `kelas`, `no_tel`, `nama_ibu`, `no_tel_ibu`, `nama_bapa`, `no_tel_bapa`, `alamat`) VALUES
(1, 'Fateh Al Qawiy', 'Abu Bakar 1', 'KPD', '0137490061', 'Fathiah Syazween', '0163419963', 'Fariz Wildan', '0153728857', 'Jalan 730, Taman Tengah'),
(2, 'Waheed Razif', 'Abu Bakar 1', 'KPD', '0142998401', 'Raisya Aliya', '0137803367', 'Raizal Irfan', '0152889014', 'Taman Bahagia'),
(3, 'Zareef Haiqal', 'Abu Bakar 1', 'KPD', '0127689440', 'Qistina Aina', '0191560371', 'Hazeeq Rizal', '0163927745', 'Taman Setia'),
(4, 'Aqil Rayyan', 'Abu Bakar 2', 'KPD', '0138452211', 'Suhaila Zahra', '0167821145', 'Shahiran Malik', '0156678321', 'Taman Cendana'),
(5, 'Luqman Haziq', 'Abu Bakar 2', 'KPD', '0149923371', 'Nur Maisarah', '0138827441', 'Hakim Razlan', '0152218972', 'Taman Mawar'),
(6, 'Danish Aiman', 'Abu Bakar 2', 'KPD', '0175409921', 'Farhana Qalesya', '0195512209', 'Azlan Hakimi', '0164423190', 'Taman Delima'),
(7, 'Adam Zafran', 'Abu Bakar 3', 'KMK', '0128893311', 'Zarina Sofea', '0172301145', 'Zulkarnain Iqbal', '0159021881', 'Taman Seri Murni'),
(8, 'Imran Qalif', 'Abu Bakar 3', 'KMK', '0137712405', 'Nur Hidayah', '0168382551', 'Faris Zulkifli', '0198823314', 'Taman Impian'),
(9, 'Haikal Danish', 'Abu Bakar 3', 'KMK', '0149928801', 'Siti Amani', '0136607442', 'Ridzuan Fakhrul', '0152314411', 'Taman Bestari'),
(10, 'Rayyan Irfan', 'Abu Bakar 4', 'KMK', '0175002211', 'Sabrina Nasuha', '0197221189', 'Hanif Razimi', '0168114205', 'Taman Cahaya'),
(11, 'Faris Iman', 'Abu Bakar 4', 'KMK', '0129946733', 'Nur Liyana', '0175508822', 'Azim Hakeem', '0192243110', 'Taman Sejahtera'),
(12, 'Arif Zayyan', 'Abu Bakar 4', 'KMK', '0138809404', 'Nurlina Safwah', '0167302245', 'Ridzwan Hamka', '0197734101', 'Taman Mesra'),
(13, 'Yusuf Aqeef', 'Abu Bakar 5', 'KMK', '0137724099', 'Suhada Balqis', '0168823345', 'Firdaus Haniff', '0157892109', 'Taman Puteri'),
(14, 'Hafiz Zahran', 'Abu Bakar 5', 'KMK', '0145567811', 'Wani Irdina', '0197711255', 'Azhar Zainal', '0172219672', 'Taman Palma'),
(15, 'Irfan Haqimi', 'Abu Bakar 5', 'KMK', '0136604421', 'Nadia Hanees', '0195513314', 'Azmeer Hakim', '0158822104', 'Taman Anggerik'),
(16, 'Mikail Arfan', 'Abu Bakar 6', 'BPM', '0174096221', 'Siti Maisarah', '0198127745', 'Lokman Hakimi', '0163455120', 'Taman Teratai'),
(17, 'Aidan Qayyum', 'Abu Bakar 6', 'BPM', '0145502871', 'Amira Adlina', '0136600991', 'Reza Farhan', '0157702811', 'Taman Sri Jaya'),
(18, 'Zikri Haziq', 'Abu Bakar 6', 'BPM', '0128913303', 'Husna Nurani', '0178823310', 'Fahmi Radzi', '0192241160', 'Taman Bahtera'),
(19, 'Rayan Hakeem', 'Abu Bakar 7', 'BPM', '0134429911', 'Sofia Nadira', '0179932205', 'Fuad Idham', '0157739201', 'Taman Melati'),
(20, 'Naufal Ziyad', 'Abu Bakar 7', 'BPM', '0149223801', 'Farahin Zahra', '0137725901', 'Azrul Hafizi', '0198843321', 'Taman Bukit Indah'),
(21, 'Izz Hafiy', 'Abu Bakar 7', 'BPM', '0175529904', 'Suraya Qistina', '0165517744', 'Rahman Fakri', '0153301887', 'Taman Wawasan'),
(22, 'Zayan Arif', 'Abu Bakar 8', 'BPM', '0137725510', 'Nur Syafiqah', '0198234411', 'Firhan Iskandar', '0165529300', 'Taman Aman'),
(23, 'Rifqi Danish', 'Abu Bakar 8', 'BPM', '0128879001', 'Alya Hurin', '0176022810', 'Danial Razak', '0192214401', 'Taman Sri Bayu'),
(24, 'Harraz Aqeel', 'Abu Bakar 8', 'BPM', '0143371980', 'Siti Munirah', '0197508912', 'Hakim Firdaus', '0158822108', 'Taman Dahlia'),
(25, 'Aiman Zafri', 'Umar 1', 'BAK', '0137724411', 'Siti Raudhah', '0168802214', 'Hafiz Razi', '0157709142', 'Taman Bukit Kencana'),
(26, 'Ehsan Haziq', 'Umar 1', 'BAK', '0149931102', 'Nur Adlina', '0196628821', 'Faiz Razman', '0175502180', 'Taman Bukit Indah'),
(27, 'Hakim Danish', 'Umar 1', 'BAK', '0128815422', 'Marlina Sofea', '0137721145', 'Azmir Zafran', '0198853301', 'Taman Seri Impian'),
(28, 'Zafran Aqeef', 'Umar 2', 'BAK', '0138857711', 'Suhaila Murni', '0165621122', 'Ridzuan Hakimi', '0178822140', 'Taman Putra Perdana'),
(29, 'Irfan Ziyad', 'Umar 2', 'BAK', '0145523390', 'Roslina Balqis', '0197104501', 'Azri Fakhrul', '0152219012', 'Taman Saujana'),
(30, 'Raiyan Harith', 'Umar 2', 'BAK', '0127703499', 'Hani Aqeela', '0174421194', 'Farhan Nazri', '0168823100', 'Taman Intan'),
(31, 'Mikael Arqam', 'Umar 3', 'BAK', '0175402215', 'Nur Maisarah', '0196541188', 'Syafik Razlan', '0157712030', 'Taman Aman Jaya'),
(32, 'Danish Imran', 'Umar 3', 'BAK', '0138811011', 'Siti Nurhani', '0177305521', 'Hazwan Khairi', '0199022111', 'Taman Desa Utama'),
(33, 'Aqil Zahir', 'Umar 3', 'BAK', '0147629901', 'Ainul Safiya', '0135598711', 'Faris Hakimi', '0159104421', 'Taman Bunga Raya'),
(34, 'Rayyan Firdaus', 'Umar 4', 'HSK', '0127789911', 'Nadia Syuhada', '0177732241', 'Fahmi Zulkifli', '0168843120', 'Taman Mutiara'),
(35, 'Haikal Aryan', 'Umar 4', 'HSK', '0149952201', 'Suraya Maisarah', '0198834411', 'Ridzuan Zakwan', '0173321084', 'Taman Desa Permai'),
(36, 'Aiman Irfan', 'Umar 4', 'HSK', '0134429105', 'Sofea Nasuha', '0165502181', 'Amirul Razif', '0197722130', 'Taman Cahaya Indah'),
(37, 'Naufal Haqeem', 'Umar 5', 'HSK', '0175521140', 'Alya Irdina', '0196603354', 'Firdaus Zafri', '0163327180', 'Taman Melur'),
(38, 'Arif Aqil', 'Umar 5', 'HSK', '0148872031', 'Siti Munirah', '0137722145', 'Shahril Hakimi', '0158824199', 'Taman Mawar'),
(39, 'Zikri Amsyar', 'Umar 5', 'HSK', '0125512202', 'Wani Syafika', '0175509921', 'Azman Ridzuan', '0167734420', 'Taman Cahaya'),
(40, 'Danish Aqeef', 'Umar 6', 'HBP', '0137725599', 'Fatin Umaira', '0176302291', 'Azri Firdaus', '0192204410', 'Taman Puteri Indah'),
(41, 'Irfan Syakir', 'Umar 6', 'HBP', '0146608821', 'Nurhana Balqis', '0197721904', 'Hazwan Idris', '0165510031', 'Taman Seri Bayu'),
(42, 'Rafif Zafran', 'Umar 6', 'HBP', '0179932140', 'Suzi Aqeela', '0163392250', 'Fadzil Hakim', '0198824417', 'Taman Orkid'),
(43, 'Harraz Aiman', 'Umar 7', 'HBP', '0127729901', 'Sofia Zahirah', '0176602280', 'Naim Razin', '0167735099', 'Taman Wawasan'),
(44, 'Zayan Daim', 'Umar 7', 'HBP', '0145507781', 'Nur Atikah', '0138821165', 'Hakim Shamsul', '0199923400', 'Taman Saga'),
(45, 'Rayyan Yusuf', 'Umar 7', 'HBP', '0137729005', 'Hasnita Zahra', '0175521199', 'Fariz Nazhan', '0156632130', 'Taman Beringin'),
(46, 'Aqeef Rayyan', 'Umar 8', 'KMK', '0134492211', 'Noradila Husna', '0197723011', 'Azman Razak', '0174415020', 'Taman Jati'),
(47, 'Danish Firhan', 'Umar 8', 'KMK', '0142237710', 'Siti Qalesya', '0167511209', 'Fahmi Razali', '0195501188', 'Taman Kenanga'),
(48, 'Rifqi Arsyad', 'Umar 8', 'KMK', '0125509924', 'Hidayah Maisarah', '0178402210', 'Ridwan Hakeem', '0164419020', 'Taman Sentosa'),
(49, 'Aisyah Sofia', 'Siti Hajar 1', 'KPD', '0137724411', 'Siti Raudhah', '0168802214', 'Hafiz Razi', '0157709142', 'Taman Bukit Kencana'),
(50, 'Nur Amirah', 'Siti Hajar 1', 'KPD', '0149931102', 'Nur Adlina', '0196628821', 'Faiz Razman', '0175502180', 'Taman Bukit Indah'),
(51, 'Siti Mariam', 'Siti Hajar 1', 'KPD', '0128815422', 'Marlina Sofea', '0137721145', 'Azmir Zafran', '0198853301', 'Taman Seri Impian'),
(52, 'Farah Nabilah', 'Siti Hajar 2', 'KPD', '0138857711', 'Suhaila Murni', '0165621122', 'Ridzuan Hakimi', '0178822140', 'Taman Putra Perdana'),
(53, 'Aina Syafika', 'Siti Hajar 2', 'KPD', '0145523390', 'Roslina Balqis', '0197104501', 'Azri Fakhrul', '0152219012', 'Taman Saujana'),
(54, 'Hani Qistina', 'Siti Hajar 2', 'KPD', '0127703499', 'Hani Aqeela', '0174421194', 'Farhan Nazri', '0168823100', 'Taman Intan'),
(55, 'Liyana Aqilah', 'Siti Hajar 3', 'KMK', '0175402215', 'Nur Maisarah', '0196541188', 'Syafik Razlan', '0157712030', 'Taman Aman Jaya'),
(56, 'Sarah Hidayah', 'Siti Hajar 3', 'KMK', '0138811011', 'Siti Nurhani', '0177305521', 'Hazwan Khairi', '0199022111', 'Taman Desa Utama'),
(57, 'Aminah Sofea', 'Siti Hajar 3', 'KMK', '0147629901', 'Ainul Safiya', '0135598711', 'Faris Hakimi', '0159104421', 'Taman Bunga Raya'),
(58, 'Nur Afiqah', 'Siti Hajar 4', 'KMK', '0127789911', 'Nadia Syuhada', '0177732241', 'Fahmi Zulkifli', '0168843120', 'Taman Mutiara'),
(59, 'Haikalina Aryana', 'Siti Hajar 4', 'KMK', '0149952201', 'Suraya Maisarah', '0198834411', 'Ridzuan Zakwan', '0173321084', 'Taman Desa Permai'),
(60, 'Ainul Irfah', 'Siti Hajar 4', 'KMK', '0134429105', 'Sofea Nasuha', '0165502181', 'Amirul Razif', '0197722130', 'Taman Cahaya Indah'),
(61, 'Nadia Haneefa', 'Siti Hajar 5', 'KMK', '0175521140', 'Alya Irdina', '0196603354', 'Firdaus Zafri', '0163327180', 'Taman Melur'),
(62, 'Aqila Farzana', 'Siti Hajar 5', 'KMK', '0148872031', 'Siti Munirah', '0137722145', 'Shahril Hakimi', '0158824199', 'Taman Mawar'),
(63, 'Zahra Amsyar', 'Siti Hajar 5', 'KMK', '0125512202', 'Wani Syafika', '0175509921', 'Azman Ridzuan', '0167734420', 'Taman Cahaya'),
(64, 'Dania Aqeefah', 'Siti Hajar 6', 'BPM', '0137725599', 'Fatin Umaira', '0176302291', 'Azri Firdaus', '0192204410', 'Taman Puteri Indah'),
(65, 'Irfana Syakirah', 'Siti Hajar 6', 'BPM', '0146608821', 'Nurhana Balqis', '0197721904', 'Hazwan Idris', '0165510031', 'Taman Seri Bayu'),
(66, 'Rafifa Zafran', 'Siti Hajar 6', 'BPM', '0179932140', 'Suzi Aqeela', '0163392250', 'Fadzil Hakim', '0198824417', 'Taman Orkid'),
(67, 'Harrazina Aiman', 'Siti Hajar 7', 'BPM', '0127729901', 'Sofia Zahirah', '0176602280', 'Naim Razin', '0167735099', 'Taman Wawasan'),
(68, 'Zayana Daimah', 'Siti Hajar 7', 'BPM', '0145507781', 'Nur Atikah', '0138821165', 'Hakim Shamsul', '0199923400', 'Taman Saga'),
(69, 'Rayyana Yusufah', 'Siti Hajar 7', 'BPM', '0137729005', 'Hasnita Zahra', '0175521199', 'Fariz Nazhan', '0156632130', 'Taman Beringin'),
(70, 'Aqeefah Rayyana', 'Siti Hajar 8', 'BPM', '0134492211', 'Noradila Husna', '0197723011', 'Azman Razak', '0174415020', 'Taman Jati'),
(71, 'Danisha Firhanah', 'Siti Hajar 8', 'BPM', '0142237710', 'Siti Qalesya', '0167511209', 'Fahmi Razali', '0195501188', 'Taman Kenanga'),
(72, 'Rifqina Arsyad', 'Siti Hajar 8', 'BPM', '0125509924', 'Hidayah Maisarah', '0178402210', 'Ridwan Hakeem', '0164419020', 'Taman Sentosa'),
(73, 'Alya Nabilah', 'Siti Aisyah 1', 'BAK', '0137724412', 'Siti Raudhah', '0168802215', 'Hafiz Razi', '0157709143', 'Taman Bukit Cempaka'),
(74, 'Sarah Izzati', 'Siti Aisyah 1', 'BAK', '0149931103', 'Nur Adlina', '0196628822', 'Faiz Razman', '0175502181', 'Taman Bukit Indah'),
(75, 'Fatin Amirah', 'Siti Aisyah 1', 'BAK', '0128815423', 'Marlina Sofea', '0137721146', 'Azmir Zafran', '0198853302', 'Taman Seri Impian'),
(76, 'Hani Liyana', 'Siti Aisyah 2', 'BAK', '0138857712', 'Suhaila Murni', '0165621123', 'Ridzuan Hakimi', '0178822141', 'Taman Putra Perdana'),
(77, 'Nur Aina', 'Siti Aisyah 2', 'BAK', '0145523391', 'Roslina Balqis', '0197104502', 'Azri Fakhrul', '0152219013', 'Taman Saujana'),
(78, 'Farah Qistina', 'Siti Aisyah 2', 'BAK', '0127703500', 'Hani Aqeela', '0174421195', 'Farhan Nazri', '0168823101', 'Taman Intan'),
(79, 'Liyana Aqilah', 'Siti Aisyah 3', 'BAK', '0175402216', 'Nur Maisarah', '0196541189', 'Syafik Razlan', '0157712031', 'Taman Aman Jaya'),
(80, 'Sarah Hidayah', 'Siti Aisyah 3', 'BAK', '0138811012', 'Siti Nurhani', '0177305522', 'Hazwan Khairi', '0199022112', 'Taman Desa Utama'),
(81, 'Aminah Sofea', 'Siti Aisyah 3', 'BAK', '0147629902', 'Ainul Safiya', '0135598712', 'Faris Hakimi', '0159104422', 'Taman Bunga Raya'),
(82, 'Nur Afiqah', 'Siti Aisyah 4', 'BAK', '0127789912', 'Nadia Syuhada', '0177732242', 'Fahmi Zulkifli', '0168843121', 'Taman Mutiara'),
(83, 'Haikalina Aryana', 'Siti Aisyah 4', 'BAK', '0149952202', 'Suraya Maisarah', '0198834412', 'Ridzuan Zakwan', '0173321085', 'Taman Desa Permai'),
(84, 'Ainul Irfah', 'Siti Aisyah 4', 'BAK', '0134429106', 'Sofea Nasuha', '0165502182', 'Amirul Razif', '0197722131', 'Taman Cahaya Indah'),
(85, 'Nadia Haneefa', 'Siti Aisyah 5', 'HSK', '0175521141', 'Alya Irdina', '0196603355', 'Firdaus Zafri', '0163327181', 'Taman Melur'),
(86, 'Aqila Farzana', 'Siti Aisyah 5', 'HSK', '0148872032', 'Siti Munirah', '0137722146', 'Shahril Hakimi', '0158824200', 'Taman Mawar'),
(87, 'Zahra Amsyar', 'Siti Aisyah 5', 'HSK', '0125512203', 'Wani Syafika', '0175509922', 'Azman Ridzuan', '0167734421', 'Taman Cahaya'),
(88, 'Dania Aqeefah', 'Siti Aisyah 6', 'HSK', '0137725600', 'Fatin Umaira', '0176302292', 'Azri Firdaus', '0192204411', 'Taman Puteri Indah'),
(89, 'Irfana Syakirah', 'Siti Aisyah 6', 'HSK', '0146608822', 'Nurhana Balqis', '0197721905', 'Hazwan Idris', '0165510032', 'Taman Seri Bayu'),
(90, 'Rafifa Zafran', 'Siti Aisyah 6', 'HSK', '0179932141', 'Suzi Aqeela', '0163392251', 'Fadzil Hakim', '0198824418', 'Taman Orkid'),
(91, 'Harrazina Aiman', 'Siti Aisyah 7', 'HBP', '0127729902', 'Sofia Zahirah', '0176602281', 'Naim Razin', '0167735100', 'Taman Wawasan'),
(92, 'Zayana Daimah', 'Siti Aisyah 7', 'HBP', '0145507782', 'Nur Atikah', '0138821166', 'Hakim Shamsul', '0199923401', 'Taman Saga'),
(93, 'Rayyana Yusufah', 'Siti Aisyah 7', 'HBP', '0137729006', 'Hasnita Zahra', '0175521200', 'Fariz Nazhan', '0156632131', 'Taman Beringin'),
(94, 'Aqeefah Rayyana', 'Siti Aisyah 8', 'HBP', '0134492212', 'Noradila Husna', '0197723012', 'Azman Razak', '0174415021', 'Taman Jati'),
(95, 'Danisha Firhanah', 'Siti Aisyah 8', 'HBP', '0142237711', 'Siti Qalesya', '0167511210', 'Fahmi Razali', '0195501189', 'Taman Kenanga'),
(96, 'Rifqina Arsyad', 'Siti Aisyah 8', 'HBP', '0125509925', 'Hidayah Maisarah', '0178402211', 'Ridwan Hakeem', '0164419021', 'Taman Sentosa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bilik`
--
ALTER TABLE `bilik`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `info_files`
--
ALTER TABLE `info_files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kehadiran`
--
ALTER TABLE `kehadiran`
  ADD PRIMARY KEY (`id_penghuni`,`tarikh`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_pengguna`);

--
-- Indexes for table `penghuni`
--
ALTER TABLE `penghuni`
  ADD PRIMARY KEY (`id_penghuni`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bilik`
--
ALTER TABLE `bilik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `info_files`
--
ALTER TABLE `info_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_pengguna` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `penghuni`
--
ALTER TABLE `penghuni`
  MODIFY `id_penghuni` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
