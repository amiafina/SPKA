<?php
include 'inc/connect.php';

// ----- PROSES UPLOAD FAIL -----
$msg = "";

if(isset($_POST['upload'])){
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $fileName = $_FILES['file']['name'];
    $tmp = $_FILES['file']['tmp_name'];

    if(!is_dir("uploads/info")){
        mkdir("uploads/info", 0777, true);
    }

    $path = "uploads/info/" . $fileName;
    move_uploaded_file($tmp, $path);

    mysqli_query($conn, "INSERT INTO info_files(title, filename) VALUES('$title', '$fileName')");

    $msg = "FAIL BERJAYA DIMUAT NAIK!";
}

// ----- PROSES DELETE -----
if(isset($_GET['delete'])){
    $id = (int)$_GET['delete'];
    $q = mysqli_query($conn, "SELECT filename FROM info_files WHERE id=$id");
    $row = mysqli_fetch_assoc($q);

    if($row){
        if(file_exists("uploads/info/".$row['filename'])){
            unlink("uploads/info/".$row['filename']);
        }
        mysqli_query($conn, "DELETE FROM info_files WHERE id=$id");
        header("Location: info.php?msg=delete_success");
        exit;
    }
}

// ----- PROSES UPDATE TAJUK -----
if(isset($_POST['save'])){
    $id = (int)$_POST['id'];
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    mysqli_query($conn, "UPDATE info_files SET title='$title' WHERE id=$id");
    header("Location: info.php?msg=update_success");
    exit;
}

// ----- TARIK SEMUA REKOD UNTUK SENARAI -----
$info_result = mysqli_query($conn, "SELECT * FROM info_files ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8">
<title>Info</title>
<link rel="stylesheet" href="css/style_sidebar.css">
<link rel="stylesheet" href="css/style_info.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

</head>
<body>
    
<?php include 'inc/sidebar.php'; ?>


<main class="upload-content">
  <div class="card">
    <h2>Muat Naik Info</h2>

    <?php if($msg != ""): ?>
        <p style="color:green; font-weight:bold; text-align:center;"><?= $msg ?></p>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" class="upload-form">
        <label>Tajuk</label>
        <input type="text" name="title" required>

        <label>Fail</label>
        <input type="file" name="file" required>

        <button type="submit" name="upload" class="btn-save">Muat Naik</button>
    </form>
</div>

    </td>

    <!-- ================= Senarai Info ================= -->
    <div class="card">
    <h2>Senarai Info</h2>
    <?php if(mysqli_num_rows($info_result) > 0): ?>
        <table class="info-table">
            <tr><th>NO</th><th>TAJUK</th><th>FAIL</th><th>TINDAKAN</th></tr>
            <?php $no=1; while($row = mysqli_fetch_assoc($info_result)): ?>
            <tr>
                <td><?= $no++ ?></td>
                <td>
                <form method="post" id="form_<?= $row['id'] ?>">
                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                    <input type="text" name="title"
                        value="<?= htmlspecialchars($row['title']) ?>"
                        id="input_<?= $row['id'] ?>">
                        <br>
                        <br>
                    <button type="button" class="btn-save" onclick="confirmSave(<?= $row['id'] ?>)">Simpan</button>
                </form>
            </td>

                <td>
                    <a href="uploads/info/<?= rawurlencode($row['filename']) ?>" target="_blank" style="text-decoration:none;">
                        <?= htmlspecialchars($row['filename']) ?>
                    </a>
                </td>
                <td>
                    <a href="#" class="delete-btn" onclick="confirmDelete(<?= $row['id'] ?>, '<?= htmlspecialchars(addslashes($row['title'])) ?>')">Padam</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>Tiada rekod info dijumpai.</p>
    <?php endif; ?>
    </div>

</main>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function logoutConfirm(event){
    event.preventDefault();
    Swal.fire({
        title: 'Log Keluar?',
        text: 'Adakah anda pasti ingin log keluar dari sistem?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Ya, Log Keluar',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6'
    }).then((result)=>{
        if(result.isConfirmed){
            window.location.href='index.php';
        }
    });
    return false;
}

function confirmDelete(id, title){
    Swal.fire({
        title: 'Padam Maklumat?',
        html: 'Anda akan memadam:<br><b>"'+title+'"</b>',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, Padam',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6'
    }).then((result)=>{
        if(result.isConfirmed){
            window.location.href='?delete='+id;
        }
    });
}

function confirmSave(id){
    var input = document.getElementById('input_'+id);
    if(input.value.trim() === ''){
        Swal.fire({
            icon:'warning',
            title:'Tajuk Kosong',
            text:'Sila isi tajuk'
        });
        input.focus();
        return;
    }
    Swal.fire({
        title:'Simpan Perubahan?',
        icon:'question',
        showCancelButton:true,
        confirmButtonText:'Ya, Simpan',
        cancelButtonText:'Batal'
    }).then((result)=>{
        if(result.isConfirmed){
            var form = document.getElementById('form_'+id);
            if(!form.querySelector('[name="save"]')){
                var hidden = document.createElement('input');
                hidden.type = 'hidden';
                hidden.name = 'save';
                hidden.value = '1';
                form.appendChild(hidden);
            }
            form.submit();
        }
    });
}

// SweetAlert success messages
<?php if($msg != ""): ?>
Swal.fire({icon:'success', title:'Berjaya!', text:'<?= $msg ?>', confirmButtonText:'OK', confirmButtonColor:'#3085d6', timer:3000, timerProgressBar:true});
<?php endif; ?>

<?php if(isset($_GET['msg']) && $_GET['msg']=='delete_success'): ?>
Swal.fire('Berjaya!','Fail dipadam','success');
<?php endif; ?>

<?php if(isset($_GET['msg']) && $_GET['msg']=='update_success'): ?>
Swal.fire('Berjaya!','Tajuk dikemaskini','success');
<?php endif; ?>
</script>

</body>
</html>
