<?php
session_start();
include 'inc/connect.php';

// SET DEFAULT TIMEZONE
date_default_timezone_set('Asia/Kuala_Lumpur');

$nama_bilik = isset($_POST['nama_bilik']) ? $_POST['nama_bilik'] : '';
$tarikh_pilih = isset($_POST['tarikh']) ? date('Y-m-d', strtotime($_POST['tarikh'])) : date('Y-m-d');

// Bilangan hadir / tak hadir
$bil_hadir = 0;
$bil_tak_hadir = 0;

// Ambil senarai bilik
$bilik_result = mysqli_query($conn, "SELECT DISTINCT nama_bilik FROM penghuni ORDER BY nama_bilik ASC");
if(!$bilik_result) {
    echo "Query error: " . mysqli_error($conn);
}
$bilik_list = [];
if($bilik_result && mysqli_num_rows($bilik_result) > 0) {
    while($b = mysqli_fetch_assoc($bilik_result)) {
        $bilik_list[] = $b;
    }
} else {
    echo "";
}

// Kalau admin submit kehadiran
$show_success = false;
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_kehadiran'])) {
    if(isset($_POST['id_penghuni'])) {
        $hadir = isset($_POST['hadir']) ? $_POST['hadir'] : [];

        foreach ($_POST['id_penghuni'] as $id) {
            $id_safe = mysqli_real_escape_string($conn, $id);
            $status = in_array($id, $hadir) ? 'Hadir' : 'Tidak Hadir';
            $catatan = isset($_POST['catatan'][$id]) ? $_POST['catatan'][$id] : '';
            $lain = isset($_POST['lain'][$id]) ? $_POST['lain'][$id] : '';

            if($catatan == 'Lain-lain' && $lain != '') {
                $catatan = $lain;
            }

            $catatan_safe = mysqli_real_escape_string($conn, $catatan);

            // REPLACE data (akan overwrite jika ada data sedia ada untuk tarikh ini)
            mysqli_query($conn, "
                REPLACE INTO kehadiran (id_penghuni, tarikh, status, catatan)
                VALUES ('$id_safe', '$tarikh_pilih', '$status', '$catatan_safe')
            ") or die("Error: " . mysqli_error($conn));
        }
        
        $show_success = true;
    }
}

// Tarik data penghuni + kehadiran untuk bilik dan tarikh yang dipilih
$result = [];
$penghuni_data = [];
if($nama_bilik != '') {
    $nama_bilik_safe = mysqli_real_escape_string($conn, $nama_bilik);
    
    // Query untuk dapatkan semua penghuni dalam bilik + status kehadiran mereka untuk tarikh pilih
    $query = "
    SELECT 
        p.id_penghuni,
        p.nama_penghuni,
        IFNULL(k.status, 'Tidak Hadir') AS status,
        IFNULL(k.catatan, '') AS catatan
    FROM penghuni p
    LEFT JOIN kehadiran k 
        ON p.id_penghuni = k.id_penghuni 
        AND DATE(k.tarikh) = DATE('$tarikh_pilih')
    WHERE p.nama_bilik = '$nama_bilik_safe'
    ORDER BY p.nama_penghuni ASC
    ";
    
    $result = mysqli_query($conn, $query) or die("Query Error: " . mysqli_error($conn));

    // Kira bilangan hadir/tidak hadir dan simpan data
    if($result && mysqli_num_rows($result) > 0){
        while($row = mysqli_fetch_assoc($result)){
            $penghuni_data[] = $row;
            if($row['status'] == 'Hadir') $bil_hadir++;
        }
        $bil_tak_hadir = count($penghuni_data) - $bil_hadir;
    }
}
?>
<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8">
<title>Kehadiran</title>
<link rel="stylesheet" href="css/style_sidebar.css">
<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<style>
* { font-family: 'Roboto', sans-serif; }
body.dashboard-page { background: #f8f9fa; margin:0; padding:0; }
.content { margin-left:240px; padding:20px; width:calc(100%-240px); min-height:100vh; background:#f8f9fa; }
.form-group { margin-bottom:15px; display:flex; align-items:center; }
.form-group label { min-width:150px; font-weight:600; }
input[type="text"], select, input[type="date"] { 
    padding:8px 10px; 
    border:1px solid #ddd; 
    border-radius:6px; 
    font-size:14px; 
    width:200px;
}
.table-container { 
    background:white; 
    border-radius:10px; 
    padding:20px; 
    margin:20px 0; 
    box-shadow:0 2px 10px rgba(0,0,0,0.05); 
    border:1px solid #eaeaea; 
    overflow-x:auto; 
}
.attendance-table { 
    width:100%; 
    border-collapse:collapse; 
    font-size:14px; 
    min-width:600px; 
}
.attendance-table thead { background:#2c3e50; color:white; }
.attendance-table th, .attendance-table td { 
    padding:12px; 
    border-bottom:1px solid #f0f0f0; 
    text-align:center; 
}
.attendance-table td:nth-child(3) { 
    text-align:left; 
    padding-left:15px; 
    font-weight:500; 
    color:#2c3e50; 
}
.attendance-table input[type="checkbox"] { 
    width:18px; 
    height:18px; 
    accent-color:#3a6d50; 
}
.attendance-table select, .attendance-table input[type="text"] { 
    width:100%; 
    box-sizing:border-box; 
}
.lainInput { 
    display:none; 
    margin-top:8px; 
    width:95%; 
}
button[type="submit"] { 
    background:#27ae60; 
    color:white; 
    padding:12px 30px; 
    border:none; 
    border-radius:8px; 
    cursor:pointer; 
    margin-top:20px; 
    font-size:16px;
    font-weight:bold;
}
button[type="submit"]:hover { background:#219653; }
.hadir-count { color:#27ae60; font-weight:bold; }
.tak-hadir-count { color:#e74c3c; font-weight:bold; }

/* Footer Minimalis */
.footer {
    background: white;
    color: #64748b;
    text-align: center;
    padding: 20px;
    border-radius: 12px;
    margin-top: auto;
    box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.04);
    border: 1px solid #eef2f7;
    font-size: 14px;
}

.footer b {
    font-weight: 500;
    color: #1e293b;
}

.footer .update-time {
    margin-top: 6px;
    font-size: 13px;
    color: #94a3b8;
}
</style>

</head>
<body class="dashboard-page">
<?php include 'inc/sidebar.php'; ?>

<main class="content">
<form method="POST" id="formKehadiran">


<div class="form-group">
    <label>BILIK:</label>
    <select name="nama_bilik" onchange="this.form.submit()" required>
        <option value="">-- PILIH BILIK --</option>
        <?php foreach($bilik_list as $b): ?>
    <?php if(!empty(trim($b['nama_bilik']))): ?>
        <option value="<?= htmlspecialchars($b['nama_bilik']) ?>"
            <?= (isset($nama_bilik) && $b['nama_bilik'] == $nama_bilik) ? "selected" : "" ?>>
            <?= htmlspecialchars($b['nama_bilik']) ?>
        </option>
    <?php endif; ?>
<?php endforeach; ?>
    </select>
</div>

<div class="form-group">
    <label>TARIKH:</label>
    <input type="date" name="tarikh" value="<?= $tarikh_pilih ?>" 
           max="<?= date('Y-m-d') ?>" onchange="this.form.submit()">
</div>

<?php if(!empty($penghuni_data)): ?>
<hr>
<div style="display:flex; gap:30px; margin-bottom:20px;">
    <div class="form-group">
        <label>BIL. HADIR:</label>
        <input type="text" value="<?= $bil_hadir ?>" readonly class="hadir-count">
    </div>
    <div class="form-group">
        <label>BIL. TIDAK HADIR:</label>
        <input type="text" value="<?= $bil_tak_hadir ?>" readonly class="tak-hadir-count">
    </div>
</div>

<div class="table-container">
<table class="attendance-table">
<thead>
<tr>
<th>BIL</th>
<th>KEHADIRAN</th>
<th>NAMA PENGHUNI</th>
<th>CATATAN</th>
</tr>
</thead>
<tbody>
<?php $i=1; foreach($penghuni_data as $row): 
    $checked = ($row['status']=='Hadir') ? "checked" : "";
    $catatan_simpan = $row['catatan'];
    
    // Tentukan sama ada catatan adalah "Lain-lain"
    // $is_lain_lain = ($catatan_simpan != "" && $catatan_simpan != "Urusan Keluarga" && $catatan_simpan != "Kesihatan");
    $kategori_standard = [
    "Urusan Keluarga",
    "Kesihatan",
    "Balik Pilihan",
    "Urusan Rasmi"
    ];

    $is_lain_lain = (
        $catatan_simpan != "" &&
        !in_array($catatan_simpan, $kategori_standard)
    );

?>
<tr>
<td><?= $i++; ?></td>
<td>
    <input type="checkbox" name="hadir[]" value="<?= $row['id_penghuni'] ?>" <?= $checked ?>>
</td>
<td><?= htmlspecialchars($row['nama_penghuni']) ?></td>
<td>
    <select name="catatan[<?= $row['id_penghuni'] ?>]" class="catatanSelect">
        <option value="" <?= ($catatan_simpan=="")?"selected":"" ?>>Sila pilih</option>
        <option value="Balik Pilihan" <?= ($catatan_simpan=="Balik Pilihan")?"selected":"" ?>>Balik Pilihan</option>
        <option value="Urusan Keluarga" <?= ($catatan_simpan=="Urusan Keluarga")?"selected":"" ?>>Urusan Keluarga</option>
        <option value="Urusan Rasmi" <?= ($catatan_simpan=="Urusan Rasmi")?"selected":"" ?>>Urusan Rasmi</option>
        <option value="Kesihatan" <?= ($catatan_simpan=="Kesihatan")?"selected":"" ?>>Kesihatan</option>
        <option value="Lain-lain" <?= $is_lain_lain?"selected":"" ?>>Lain-lain</option>
    </select>
    <input type="text" name="lain[<?= $row['id_penghuni'] ?>]" 
           class="lainInput" 
           value="<?= $is_lain_lain ? htmlspecialchars($catatan_simpan) : '' ?>" 
           placeholder="Sila taip sebab">
</td>
<input type="hidden" name="id_penghuni[]" value="<?= $row['id_penghuni'] ?>">
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>

<div style="text-align:right;">
<button type="submit" name="hantar">HANTAR KEHADIRAN</button> 
<br><br><br>
</div>

        <div class="footer">
            <b>© <?php echo date('Y'); ?> SPKA | Sistem Pengurusan Kehadiran Asrama</b>
            <div class="update-time">Dikemaskini: <?php echo date('H:i:s'); ?></div>
        </div>

<?php elseif($nama_bilik != ''): ?>
<div style="background:#f8d7da; color:#721c24; padding:15px; border-radius:6px; margin-top:20px;">
    Tiada penghuni ditemui untuk bilik ini.
</div>
<?php endif; ?>
</form>
</main>

<script>
// Show/hide input lain-lain
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.catatanSelect').forEach(function(select){
        // Set initial state
        let inputLain = select.nextElementSibling;
        if(select.value == 'Lain-lain') {
            inputLain.style.display = 'block';
        }
        
        // Add change event
        select.addEventListener('change', function(){
            let inputLain = this.nextElementSibling;
            if(this.value == 'Lain-lain'){ 
                inputLain.style.display = 'block';
                inputLain.focus();
            } else { 
                inputLain.style.display = 'none'; 
                inputLain.value = ''; 
            }
        });
    });
});

// Popup berjaya
<?php if($show_success): ?>
Swal.fire({
    title:'Berjaya!',
    text:'Rekod kehadiran berjaya disimpan.',
    icon:'success',
    confirmButtonText:'OK',
    timer:3000,
    timerProgressBar:true
});
<?php endif; ?>
</script>

</body>
</html>