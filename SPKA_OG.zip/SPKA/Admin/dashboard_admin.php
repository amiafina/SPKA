<?php
session_start();

// SEMAK JIKA ADMIN TELAH LOGIN
if (!isset($_SESSION['nama_pengguna']) || !isset($_SESSION['peranan']) || $_SESSION['peranan'] !== 'admin') {
    // Redirect ke login jika bukan admin
    header("Location: index.php");
    exit();
}

include 'inc/connect.php';
date_default_timezone_set('Asia/Kuala_Lumpur');

/* ===============================
   TENTUKAN TARIKH PAPARAN DASHBOARD
   =============================== */
if (date('H:i') <= '21:15') {
    // sebelum 9:15 malam → papar data semalam
    $tarikhPaparan = date('Y-m-d', strtotime('-1 day'));
} else {
    // selepas 9:16 malam → papar hari ini
    $tarikhPaparan = date('Y-m-d'); // <- ni kalau nk tgk tarikh hari ni live rekod kehadiran
}

/* ===============================
   FUNCTION KIRA HADIR / TIDAK HADIR
   =============================== */

// ---LAMA---
// function getHadir($conn, $nama_bilik){
//     global $tarikhPaparan;

//     $q = mysqli_query($conn, "
//         SELECT 
//             SUM(status = 'Hadir') AS hadir,
//             SUM(status = 'Tidak Hadir') AS tidak
//         FROM kehadiran k
//         JOIN penghuni p ON p.id_penghuni = k.id_penghuni
//         WHERE p.nama_bilik = '$nama_bilik'
//           AND k.tarikh = '$tarikhPaparan'
//     ");

//     $data = mysqli_fetch_assoc($q);

//     return [
//         'hadir' => $data['hadir'] ?? 0,
//         'tidak' => $data['tidak'] ?? 0
//     ];
// }

function getHadir($conn, $nama_bilik){
    global $tarikhPaparan;

    $q = mysqli_query($conn, "
        SELECT 
            SUM(k.status = 'Hadir') AS hadir,
            SUM(k.status = 'Tidak Hadir') AS tidak
        FROM kehadiran k
        JOIN penghuni p ON p.id_penghuni = k.id_penghuni
        WHERE p.nama_bilik = '$nama_bilik'
          AND k.tarikh = '$tarikhPaparan'
    ");

    $data = mysqli_fetch_assoc($q);

    return [
        'hadir' => $data['hadir'] ?? 0,
        'tidak' => $data['tidak'] ?? 0
    ];
}


function getHadirBlock($conn, $blockName, $bilikPerBlock=8){
    $hadir = 0; 
    $tidak = 0;

    for($i=1; $i<=$bilikPerBlock; $i++){
        $roomName = "$blockName $i";
        $data = getHadir($conn, $roomName);
        $hadir += $data['hadir'];
        $tidak += $data['tidak'];
    }

    return ['hadir'=>$hadir,'tidak'=>$tidak];
}

/* ===============================
   DATA BLOK & BILIK
   =============================== */
$bilikPerBlock = 8;
$blocks = ['ABU BAKAR', 'UMAR', 'SITI KHADIJAH', 'SITI AISYAH', 'SITI HAJAR'];
$aspuraBlocks = ['ABU BAKAR', 'UMAR'];
$aspuriBlocks = ['SITI KHADIJAH', 'SITI AISYAH', 'SITI HAJAR'];

$totalAspura = ['hadir' => 0, 'tidak' => 0];
$totalAspuri = ['hadir' => 0, 'tidak' => 0];
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Papan Muka</title>
    <link rel="stylesheet" href="css/style_sidebar.css">
    <link rel="stylesheet" href="css/style_dashboard.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
<div class="page-wrapper">
    <?php
    $bulanBM = [
    'Januari', 'Februari', 'Mac', 'April', 'Mei', 'Jun',
    'Julai', 'Ogos', 'September', 'Oktober', 'November', 'Disember'
    ];

    $tarikhBM = date('d') . ' ' . $bulanBM[date('n') - 1] . ' ' . date('Y');
    ?>

    <?php include 'inc/sidebar.php'; ?>
    
    <div class="content">
        <!-- Header Minimalis -->
        <header class="header">
            <div class="header-content">
                <h1>SISTEM PENGURUSAN KEHADIRAN ASRAMA (SPKA)</h1>
                <h4>Selamat Datang, <?php echo $_SESSION['nama_pengguna'] ?? ''; ?></h4>
            </div>
            <div id="currentDateTime" style="font-weight: 500; color: #475569;">
        </header>

        <!-- Page Title Simple -->
        <div class="page-title">
            <h3>Statistik Harian Penghuni Asrama</h3>
            <span class="date"><?php echo $tarikhBM; ?></span>
        </div>

        <!-- Table Simple -->
        <div class="table-container">
            <table class="attendance-table">
                <thead>
                    <tr>
                        <th>Bilik</th>
                        <?php for ($i = 1; $i <= $bilikPerBlock; $i++): ?>
                            <th><?= $i ?></th>
                        <?php endfor; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($blocks as $block): ?>
                    <tr>
                        <td><b><?= $block ?></b></td>
                        <?php for ($i = 1; $i <= $bilikPerBlock; $i++):
                            $roomName = "$block $i";
                            $data = getHadir($conn, $roomName);
                            $total = $data['hadir'] + $data['tidak'];
                        ?>
                        <td>
                            <span style="font-weight: 500; color: #10b981;"><?= $data['hadir'] ?></span>
                            <span style="color: #94a3b8;"> / </span>
                            <span><?= $total ?></span>
                        </td>
                        <?php endfor; ?>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Cards Section Minimalis -->
        <div class="cards-container">
            <!-- ASPURA -->
            <div class="section-title">Aspura (Lelaki)</div>
            <div class="cards-row">
                <?php foreach ($aspuraBlocks as $block):
                    $data = getHadirBlock($conn, $block, $bilikPerBlock);
                    $totalAspura['hadir'] += $data['hadir'];
                    $totalAspura['tidak'] += $data['tidak'];
                ?>
                <div class="card biru">
                    <h3><?= $block ?></h3>
                    <p class="stat"><?= $data['hadir'] ?> Hadir</p>
                    <p class="stat"><?= $data['tidak'] ?> Tidak Hadir</p>
                </div>
                <?php endforeach; ?>
                
                <div class="card biru aspura">
                    <h3>Jumlah Aspura</h3>
                    <p class="total-stat">
                        <?= $totalAspura['hadir'] . ' / ' . ($totalAspura['hadir'] + $totalAspura['tidak']) ?>
                    </p>
                </div>
            </div>
            
            <div class="separator"></div>
            
            <!-- ASPURI -->
            <div class="section-title">Aspuri (Perempuan)</div>
            <div class="cards-row">
                <?php foreach ($aspuriBlocks as $block):
                    $data = getHadirBlock($conn, $block, $bilikPerBlock);
                    $totalAspuri['hadir'] += $data['hadir'];
                    $totalAspuri['tidak'] += $data['tidak'];
                ?>
                <div class="card pink">
                    <h3><?= $block ?></h3>
                    <p class="stat"><?= $data['hadir'] ?> Hadir</p>
                    <p class="stat"><?= $data['tidak'] ?> Tidak Hadir</p>
                </div>
                <?php endforeach; ?>
                
                <div class="card pink aspuri">
                    <h3>Jumlah Aspuri</h3>
                    <p class="total-stat">
                        <?= $totalAspuri['hadir'] . ' / ' . ($totalAspuri['hadir'] + $totalAspuri['tidak']) ?>
                    </p>
                </div>
            </div>
            
            <!-- TOTAL -->
            <div class="cards-row">
                <div class="card oren">
                    <h3>Jumlah Keseluruhan</h3>
                    <p class="total-stat">
                        <?= ($totalAspura['hadir'] + $totalAspuri['hadir']) ?>
                        /
                        <?= ($totalAspura['hadir'] + $totalAspura['tidak'] + $totalAspuri['hadir'] + $totalAspuri['tidak']) ?>
                    </p>
                    <p class="stat" style="margin-top: 10px; font-size: 14px;">
                        Kehadiran Hari Ini
                    </p>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <div class="footer">
            <b>© <?php echo date('Y'); ?> SPKA | Sistem Pengurusan Kehadiran Asrama</b>
            <div class="update-time">Dikemaskini: <?php echo date('H:i:s'); ?></div>
        </div>
    </div>
</div>
    <script>
    // Function untuk update date & time
    function updateDateTime() {
        const now = new Date();
        
        // Format tarikh dalam Bahasa Melayu
        const options = { 
            weekday: 'long', 
            day: 'numeric', 
            month: 'long', 
            year: 'numeric',
            hour: '2-digit', 
            minute: '2-digit', 
            second: '2-digit',
            hour12: false,
            timeZone: 'Asia/Kuala_Lumpur'
        };
        
        try {
            // Format untuk display
            const formattedDate = now.toLocaleDateString('ms-MY', options);
            document.getElementById('currentDateTime').textContent = formattedDate;
        } catch (error) {
            // Fallback jika locale error
            const days = ['Ahad', 'Isnin', 'Selasa', 'Rabu', 'Khamis', 'Jumaat', 'Sabtu'];
            const months = ['Januari', 'Februari', 'Mac', 'April', 'Mei', 'Jun', 
                        'Julai', 'Ogos', 'September', 'Oktober', 'November', 'Disember'];
            
            const dayName = days[now.getDay()];
            const date = now.getDate();
            const monthName = months[now.getMonth()];
            const year = now.getFullYear();
            const time = now.toLocaleTimeString('ms-MY', {hour12: false});
            
            document.getElementById('currentDateTime').textContent = 
                `${dayName}, ${date} ${monthName} ${year} ${time}`;
        }
    }

    // Panggil function serta-merta
    updateDateTime();

    // Update setiap saat
    setInterval(updateDateTime, 1000);

    // Pastikan script berjalan selepas page load
    document.addEventListener('DOMContentLoaded', function() {
        updateDateTime();
    });
    </script>

</body>
</html>