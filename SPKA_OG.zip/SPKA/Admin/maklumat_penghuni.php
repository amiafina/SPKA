<?php
session_start();
include 'inc/connect.php'; // sambungan DB

function e($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

/* Messages */
$msg = '';
$msg_class = '';

/* Handle POST actions: edit save, delete confirm */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mode = $_GET['mode'] ?? '';
    if ($mode === 'edit' && isset($_GET['id_penghuni'])) {
    $id_penghuni = intval($_GET['id_penghuni']);

    // Ambil nilai asal dari DB
    $stmt = $conn->prepare("SELECT * FROM penghuni WHERE id_penghuni=?");
    $stmt->bind_param('i', $id_penghuni);
    $stmt->execute();
    $res = $stmt->get_result();
    $row_db = $res->fetch_assoc();
    $stmt->close();

    // Ambil dari POST, fallback ke DB jika kosong
    $nama_penghuni = $_POST['nama_penghuni'] ?? $row_db['nama_penghuni'];
    $no_tel = $_POST['no_tel'] ?? $row_db['no_tel'];
    $kelas = $_POST['kelas'] ?? $row_db['kelas'];
    $nama_bilik = $_POST['bilik'] ?? $row_db['nama_bilik']; // ⚠️ critical fix
    $nama_penjaga1 = $_POST['nama_penjaga1'] ?? $row_db['nama_penjaga1'];
    $no_tel_penjaga1 = $_POST['no_tel_penjaga1'] ?? $row_db['no_tel_penjaga1'];
    $hubungan_penjaga1 = $_POST['hubungan_penjaga1'] ?? $row_db['hubungan_penjaga1'];
    
    if ($hubungan_penjaga1 === 'lain') {
        $hubungan_penjaga1 = trim($_POST['hubungan_penjaga1_lain'] ?? '');
    }

    $nama_penjaga2 = $_POST['nama_penjaga2'] ?? $row_db['nama_penjaga2'];
    $no_tel_penjaga2 = $_POST['no_tel_penjaga2'] ?? $row_db['no_tel_penjaga2'];
    $hubungan_penjaga2 = $_POST['hubungan_penjaga2'] ?? $row_db['hubungan_penjaga2'];
    
    if ($hubungan_penjaga2 === 'lain') {
        $hubungan_penjaga2 = trim($_POST['hubungan_penjaga2_lain'] ?? '');
    }
    
    $alamat = $_POST['alamat'] ?? $row_db['alamat'];

    // UPDATE statement tetap sama
    $sql = "UPDATE penghuni 
            SET nama_penghuni = ?, no_tel = ?, kelas = ?, nama_bilik = ?, 
                nama_penjaga1 = ?, no_tel_penjaga1 = ?, hubungan_penjaga1 = ?, 
                nama_penjaga2 = ?, no_tel_penjaga2 = ?, hubungan_penjaga2 = ?, 
                alamat = ?  
            WHERE id_penghuni = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sssssssssssi', 
        $nama_penghuni, $no_tel, $kelas, $nama_bilik,
        $nama_penjaga1, $no_tel_penjaga1, $hubungan_penjaga1,
        $nama_penjaga2, $no_tel_penjaga2, $hubungan_penjaga2,
        $alamat, $id_penghuni
    );

    if ($stmt->execute()) {
        $bilik_redirect = $nama_bilik;
        header('Location: maklumat_penghuni.php?msg=' . urlencode('Kemaskini berjaya.') . '&bilik=' . urlencode($bilik_redirect));
        exit;
    } else {
        $msg = "Ralat: Gagal kemaskini.";
        $msg_class = "msg-error";
    }
    $stmt->close();
    
    } elseif ($mode === 'delete' && isset($_GET['id_penghuni'])) {
        $id_penghuni = intval($_GET['id_penghuni']);
        if (isset($_POST['confirm']) && $_POST['confirm'] === 'yes') {
            $stmt = $conn->prepare("DELETE FROM penghuni WHERE id_penghuni = ?");
            $stmt->bind_param('i', $id_penghuni);
            if ($stmt->execute()) {
                $bilik_redirect = $_GET['bilik'] ?? '';
                header('Location: maklumat_penghuni.php?msg=' . urlencode('Rekod berjaya dipadamkan.') . '&bilik=' . urlencode($bilik_redirect));
                exit;
            } else {
                $msg = "Ralat: Gagal padam rekod.";
                $msg_class = "msg-error";
            }
            $stmt->close();
        } else {
            header('Location: maklumat_penghuni.php');
            exit;
        }
    }
}

/* Optional: show message from GET */
if (isset($_GET['msg'])) {
    $msg = e($_GET['msg']);
    $msg_class = 'msg-success';
}

/* Helper: get distinct dorms (bilik) */
$dorms = [];
$res = $conn->query("SELECT nama_bilik FROM bilik ORDER BY nama_bilik ASC");
if ($res) {
    while ($r = $res->fetch_assoc()) {
        $dorms[] = $r['nama_bilik'];
    }
    $res->free();
}

/* Determine mode */
$mode = $_GET['mode'] ?? 'list';

/* Bilik yang dipilih untuk paparan table */
$selected_dorm = $_GET['bilik'] ?? '';
$search = trim($_GET['q'] ?? '');
?>
<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Maklumat Penghuni</title>
<link rel="stylesheet" href="css/style_sidebar.css">
<link rel="stylesheet" href="css/style_maklumat.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="dashboard-page">

<?php include 'inc/sidebar.php'; ?>

<div class="content">
<div class="container">
<h2>Maklumat Pelajar</h2>

<?php if($msg): ?>
    <div class="msg <?= e($msg_class) ?>"><?= e($msg) ?></div>
<?php endif; ?>

<?php
// ---------------- VIEW MODE ----------------
if($mode==='view' && isset($_GET['id_penghuni'])):
    $id_penghuni = intval($_GET['id_penghuni']);
    $stmt = $conn->prepare("SELECT * FROM penghuni WHERE id_penghuni=?");
    $stmt->bind_param("i",$id_penghuni);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $stmt->close();
    if($row):
?>
    <a class="back-link" href="maklumat_penghuni.php?bilik=<?= urlencode($row['nama_bilik']) ?>">&larr; Kembali ke senarai</a>
    <div class="detail-card">
        <div class="detail-row">
            <div class="detail-label">Nama:</div>
            <div class="detail-value"><?= e($row['nama_penghuni']) ?></div>
        </div>
        <div class="detail-row">
            <div class="detail-label">Kelas:</div>
            <div class="detail-value"><?= e($row['kelas']) ?></div>
        </div>
        <div class="detail-row">
            <div class="detail-label">Bilik:</div>
            <div class="detail-value"><?= e($row['nama_bilik']) ?></div>
        </div>
        <div class="detail-row">
            <div class="detail-label">No Telefon:</div>
            <div class="detail-value"><?= e($row['no_tel']) ?></div>
        </div>
        <div class="detail-row">
            <div class="detail-label">Nama Penjaga 1:</div>
            <div class="detail-value"><?= e($row['nama_penjaga1']) ?></div>
        </div>
        <div class="detail-row">
            <div class="detail-label">No Telefon Penjaga 1:</div>
            <div class="detail-value"><?= e($row['no_tel_penjaga1']) ?></div>
        </div>
        <div class="detail-row">
            <div class="detail-label">Hubungan Penjaga 1:</div>
            <div class="detail-value"><?= e($row['hubungan_penjaga1']) ?></div>
        </div>
        <div class="detail-row">
            <div class="detail-label">Nama Penjaga 2:</div>
            <div class="detail-value"><?= e($row['nama_penjaga2']) ?></div>
        </div>
        <div class="detail-row">
            <div class="detail-label">No Telefon Penjaga 2:</div>
            <div class="detail-value"><?= e($row['no_tel_penjaga2']) ?></div>
        </div>
        <div class="detail-row">
            <div class="detail-label">Hubungan Penjaga 2:</div>
            <div class="detail-value"><?= e($row['hubungan_penjaga2']) ?></div>
        </div>
        <div class="detail-row">
            <div class="detail-label">Alamat Rumah:</div>
            <div class="detail-value"><?= nl2br(e($row['alamat'])) ?></div>
        </div>
        <div class="form-actions" style="margin-top:30px;">   
            <a class="btn btn-edit" href="maklumat_penghuni.php?mode=edit&id_penghuni=<?= $row['id_penghuni'] ?>">Kemaskini</a>
            <form style="display:inline-block" method="post" action="maklumat_penghuni.php?mode=delete&id_penghuni=<?= $row['id_penghuni'] ?>&bilik=<?= urlencode($row['nama_bilik']) ?>"
                  onsubmit="return confirmDelete(event, '<?= addslashes($row['nama_penghuni']) ?>');">
                <input type="hidden" name="confirm" value="yes">
                <button class="btn btn-delete" type="submit">Padam</button>
            </form>
        </div>
    </div>
<?php else: ?>
    <div class="msg msg-error">Rekod tidak dijumpai.</div>
<?php endif; ?>

<?php
// ---------------- EDIT MODE ----------------
elseif($mode==='edit' && isset($_GET['id_penghuni'])):
    $id_penghuni = intval($_GET['id_penghuni']);
    $stmt = $conn->prepare("SELECT * FROM penghuni WHERE id_penghuni=?");
    $stmt->bind_param("i",$id_penghuni);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $stmt->close();
    if($row):
?>

<a class="back-link" href="maklumat_penghuni.php?bilik=<?= urlencode($row['nama_bilik']) ?>">&larr; Kembali ke senarai</a>
<h3>Kemaskini Maklumat: <?= e($row['nama_penghuni']) ?></h3>

<form method="post" action="maklumat_penghuni.php?mode=edit&id_penghuni=<?= $row['id_penghuni'] ?>&bilik=<?= urlencode($row['nama_bilik']) ?>" id="editForm">
    <div class="form-grid">
        <!-- Nama -->
        <div class="form-row">
            <label>Nama</label>
            <input name="nama_penghuni" required value="<?= e($row['nama_penghuni']) ?>" style="text-transform: uppercase;">
        </div>

        <!-- No Telefon -->
        <div class="form-row">
            <label>No Telefon</label>
            <input name="no_tel" value="<?= e($row['no_tel']) ?>" style="text-transform: uppercase;">
        </div>

        <!-- Kelas -->
        <div class="form-row">
            <label>Kelas</label>
            <input name="kelas" value="<?= e($row['kelas']) ?>" style="text-transform: uppercase;">
        </div>

        <!-- Bilik -->
        <div class="form-row">
            <label>Bilik</label>
            <input name="bilik" value="<?= e($row['nama_bilik']) ?>" style="text-transform: uppercase;">
        </div>

        <!-- Penjaga 1 -->
        <div class="form-row">
            <label>Nama Penjaga 1</label>
            <input name="nama_penjaga1" value="<?= e($row['nama_penjaga1']) ?>" style="text-transform: uppercase;">
        </div>

        <div class="form-row">
            <label>No Telefon Penjaga 1</label>
            <input name="no_tel_penjaga1" value="<?= e($row['no_tel_penjaga1']) ?>" style="text-transform: uppercase;">
        </div>

        <div class="form-row">
            <label>Hubungan Penjaga 1</label>
            <select name="hubungan_penjaga1" id="hubunganSelect1" required style="text-transform: uppercase;">
                <option value="">Sila Pilih Hubungan ▾</option>
                <option value="ibu" <?= ($row['hubungan_penjaga1']=='ibu')?'selected':''; ?>>IBU</option>
                <option value="bapa" <?= ($row['hubungan_penjaga1']=='bapa')?'selected':''; ?>>BAPA</option>
                <option value="adik_beradik" <?= ($row['hubungan_penjaga1']=='adik_beradik')?'selected':''; ?>>ADIK-BERADIK</option>
                <option value="datuk" <?= ($row['hubungan_penjaga1']=='datuk')?'selected':''; ?>>DATUK</option>
                <option value="nenek" <?= ($row['hubungan_penjaga1']=='nenek')?'selected':''; ?>>NENEK</option>
                <option value="lain" <?= (!in_array($row['hubungan_penjaga1'], ['ibu','bapa','adik_beradik','datuk','nenek']) && $row['hubungan_penjaga1']!='')?'selected':''; ?>>LAIN-LAIN</option>
            </select>

            <input type="text" name="hubungan_penjaga1_lain" id="lainText1"
                   placeholder="Taip hubungan lain"
                   value="<?= (!in_array($row['hubungan_penjaga1'], ['ibu','bapa','adik_beradik','datuk','nenek'])) ? e($row['hubungan_penjaga1']) : '' ?>"
                   style="margin-top:6px; display:<?= (!in_array($row['hubungan_penjaga1'], ['ibu','bapa','adik_beradik','datuk','nenek']) && $row['hubungan_penjaga1']!='') ? 'block' : 'none' ?>; text-transform: uppercase;">
        </div>

        <br>
        <!-- Penjaga 2 -->
        <div class="form-row">
            <label>Nama Penjaga 2</label>
            <input name="nama_penjaga2" value="<?= e($row['nama_penjaga2']) ?>" style="text-transform: uppercase;">
        </div>

        <div class="form-row">
            <label>No Telefon Penjaga 2</label>
            <input name="no_tel_penjaga2" value="<?= e($row['no_tel_penjaga2']) ?>" style="text-transform: uppercase;">
        </div>

        <div class="form-row">
            <label>Hubungan Penjaga 2</label>
            <select name="hubungan_penjaga2" id="hubunganSelect2" required style="text-transform: uppercase;">
                <option value="">Sila Pilih Hubungan ▾</option>
                <option value="ibu" <?= ($row['hubungan_penjaga2']=='ibu')?'selected':''; ?>>IBU</option>
                <option value="bapa" <?= ($row['hubungan_penjaga2']=='bapa')?'selected':''; ?>>BAPA</option>
                <option value="adik_beradik" <?= ($row['hubungan_penjaga2']=='adik_beradik')?'selected':''; ?>>ADIK-BERADIK</option>
                <option value="datuk" <?= ($row['hubungan_penjaga2']=='datuk')?'selected':''; ?>>DATUK</option>
                <option value="nenek" <?= ($row['hubungan_penjaga2']=='nenek')?'selected':''; ?>>NENEK</option>
                <option value="lain" <?= (!in_array($row['hubungan_penjaga2'], ['ibu','bapa','adik_beradik','datuk','nenek']) && $row['hubungan_penjaga2']!='')?'selected':''; ?>>LAIN-LAIN</option>
            </select>

            <input type="text" name="hubungan_penjaga2_lain" id="lainText2"
                placeholder="Taip hubungan lain"
                value="<?= (!in_array($row['hubungan_penjaga2'], ['ibu','bapa','adik_beradik','datuk','nenek'])) ? e($row['hubungan_penjaga2']) : '' ?>"
                style="margin-top:6px; display:<?= (!in_array($row['hubungan_penjaga2'], ['ibu','bapa','adik_beradik','datuk','nenek']) && $row['hubungan_penjaga2']!='') ? 'block' : 'none' ?>; text-transform: uppercase;">
        </div>

        <!-- Alamat -->
        <div class="form-row" style="grid-column:1/-1">
            <label>Alamat</label>
            <textarea name="alamat" rows="3" style="text-transform: uppercase;"><?= e($row['alamat']) ?></textarea>
        </div>
    </div>

    <div class="form-actions" style="margin-top:20px;">
        <button type="submit" class="btn-save">Simpan</button>
        <a href="maklumat_penghuni.php?bilik=<?= urlencode($row['nama_bilik']) ?>" class="btn btn-cancel">Batal</a>
    </div>
</form>

<script>
document.getElementById('hubunganSelect1').addEventListener('change', function() {
    var lainInput = document.getElementById('lainText1');
    if (this.value === 'lain') {
        lainInput.style.display = 'block';
    } else {
        lainInput.style.display = 'none';
        lainInput.value = '';
    }
});

document.getElementById('hubunganSelect2').addEventListener('change', function() {
    var lainInput = document.getElementById('lainText2');
    if (this.value === 'lain') {
        lainInput.style.display = 'block';
    } else {
        lainInput.style.display = 'none';
        lainInput.value = '';
    }
});

</script>

<?php else: ?>
    <div class="msg msg-error">Rekod tidak dijumpai untuk diedit.</div>
<?php endif; ?>

<?php
// ---------------- LIST MODE ----------------
else:
?>
<div class="header-bar">
  <div class="left-controls">
    <form id="filterForm" method="get" style="display:flex;gap:8px;align-items:center;">
      <label for="dorm">Pilih Bilik:</label>
      <select id="dorm" name="bilik" onchange="this.form.submit();">
        <option value="">-- Sila Pilih Bilik --</option>
        <?php foreach ($dorms as $d): ?>
          <option value="<?= e($d) ?>" <?= ($selected_dorm===$d)?'selected':'' ?>><?= e($d) ?></option>
        <?php endforeach; ?>
      </select>
    </form>
  </div>
  <div class="right-controls">
    <form method="get" style="display:flex;gap:8px;align-items:center;">
      <input type="hidden" name="bilik" value="<?= e($selected_dorm) ?>">
      <input type="search" name="q" placeholder="Cari nama..." value="<?= e($search) ?>">
      <button class="btn" type="submit">Cari</button>
      <a href="maklumat_penghuni.php" class="btn">Set Semula</a>
    </form>
  </div>
</div>

<div class="table-wrap">
  <table class="table">
    <thead>
      <tr>
        <th>Bil</th>
        <th>Nama</th>
        <th>No Telefon</th>
        <th>Kelas</th>
        <th>Perkara</th>
      </tr>
    </thead>
    <tbody>
    <?php
    $hasResults = false;
    
    if ($search !== '') {
        // Carian GLOBAL — tanpa ikut bilik
        $sql = "SELECT * FROM penghuni WHERE nama_penghuni LIKE ? ORDER BY nama_penghuni ASC";
        $stmt = $conn->prepare($sql);
        $like = "%$search%";
        $stmt->bind_param("s", $like);
        $hasResults = true;
        
    } elseif ($selected_dorm !== '') {
        // Carian ikut bilik sahaja
        $sql = "SELECT * FROM penghuni WHERE nama_bilik=? ORDER BY nama_penghuni ASC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $selected_dorm);
        $hasResults = true;
    }
    
    if ($hasResults) {
        $stmt->execute();
        $res = $stmt->get_result();
        
        $i = 1;
        while($r = $res->fetch_assoc()):
    ?>
        <tr>
            <td><?= $i ?></td>
            <td>
                <a class="name-link" href="maklumat_penghuni.php?mode=view&id_penghuni=<?= $r['id_penghuni'] ?>">
                    <?= strtoupper(e($r['nama_penghuni'])) ?>
                </a>
            </td>

            <td><?= e($r['no_tel']) ?></td>
            <td><?= e($r['kelas']) ?></td>
            <td>
                <a class="btn btn-edit" href="maklumat_penghuni.php?mode=edit&id_penghuni=<?= $r['id_penghuni'] ?>">
                    Kemaskini
                </a>
                <form style="display:inline-block" method="post" 
                      action="maklumat_penghuni.php?mode=delete&id_penghuni=<?= $r['id_penghuni'] ?>&bilik=<?= urlencode($r['nama_bilik']) ?>"
                      onsubmit="return confirmDelete(event, '<?= addslashes($r['nama_penghuni']) ?>');">
                    <input type="hidden" name="confirm" value="yes">
                    <button class="btn btn-delete" type="submit">Padam</button>
                </form>
            </td>
        </tr>
    <?php
            $i++;
        endwhile;
        
        if ($i === 1) {
            echo '<tr><td colspan="5">Tiada rekod dijumpai.</td></tr>';
        }
        
        $stmt->close();
    } else {
        echo '<tr><td colspan="5">Sila pilih bilik atau masukkan carian.</td></tr>';
    }
    ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

</div>
</div>

<script>
function confirmDelete(event, name) {
    event.preventDefault();
    Swal.fire({
        title: 'Adakah anda pasti?',
        text: 'Anda akan memadamkan rekod: ' + name,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, padam!',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6'
    }).then((result) => {
        if (result.isConfirmed) {
            event.target.submit();
        }
    });
}

function confirmEdit(event, name) {
    event.preventDefault();
    Swal.fire({
        title: 'Simpan Perubahan?',
        text: 'Adakah anda ingin menyimpan perubahan untuk ' + name + '?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Ya, simpan',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33'
    }).then((result) => {
        if (result.isConfirmed) {
            event.target.submit();
        }
    });
}
// Untuk edit button
document.querySelectorAll('[id^="editForm"]').forEach(form => {
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        const name = this.querySelector('[name="nama_penghuni"]')?.value || 'pelajar ini';
        Swal.fire({
            title: 'Simpan Perubahan?',
            text: 'Adakah anda ingin menyimpan perubahan untuk ' + name + '?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Ya, simpan',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                this.submit();
            }
        });
    });
});

// Untuk delete button
document.querySelectorAll('[id^="deleteForm"]').forEach(form => {
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        const name = this.closest('tr').querySelector('.name-link')?.textContent || 'pelajar ini';
        Swal.fire({
            title: 'Padam Rekod?',
            text: 'Adakah anda pasti ingin memadamkan rekod: ' + name + '?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Ya, padam!',
            cancelButtonText: 'Batal',
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6'
        }).then((result) => {
            if (result.isConfirmed) {
                this.submit();
            }
        });
    });
});
</script>

</body>
</html>