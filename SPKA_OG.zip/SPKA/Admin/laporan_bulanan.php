<?php
include 'inc/connect.php';

// Dapatkan bilik untuk dropdown
$list_bilik = mysqli_query($conn, "SELECT DISTINCT nama_bilik FROM penghuni WHERE nama_bilik != '' ORDER BY nama_bilik");

// Dapatkan filter
$bulan = $_GET['bulan'] ?? date('m');
$tahun = $_GET['tahun'] ?? date('Y');
$bilik_pilih = $_GET['nama_bilik'] ?? "Semua";

// Query berdasarkan filter
if ($bilik_pilih != "" && $bilik_pilih != "Semua") {
    $penghuni = mysqli_query($conn, "
        SELECT id_penghuni, nama_penghuni, nama_bilik, kelas 
        FROM penghuni 
        WHERE nama_bilik = '".mysqli_real_escape_string($conn, $bilik_pilih)."'
        ORDER BY nama_penghuni
    ");
} else {
    $penghuni = mysqli_query($conn, "
        SELECT id_penghuni, nama_penghuni, nama_bilik, kelas 
        FROM penghuni 
        ORDER BY nama_bilik, nama_penghuni
    ");
}

// Simpan data
$data = [];
$total_hari = cal_days_in_month(CAL_GREGORIAN, $bulan, $tahun);

// Statistik
$jumlah_penghuni = 0;
$jumlah_hadir_total = 0;
$jumlah_tidak_hadir_total = 0;
$hadir_per_hari = array_fill(1, $total_hari, 0);

while ($p = mysqli_fetch_assoc($penghuni)) {
    $id_penghuni = $p['id_penghuni'];
    $jumlah_penghuni++;

    $data[$id_penghuni] = [
        'nama' => $p['nama_penghuni'],
        'nama_bilik' => $p['nama_bilik'],
        'kelas' => $p['kelas'],
        'hari' => array_fill(1, $total_hari, '-'),
        'hadir_count' => 0,
        'tidak_hadir_count' => 0
    ];

    // Ambil kehadiran bulan ini
    $q = mysqli_query($conn, "
        SELECT DAY(tarikh) AS hari, status
        FROM kehadiran
        WHERE id_penghuni='$id_penghuni'
          AND MONTH(tarikh)='$bulan'
          AND YEAR(tarikh)='$tahun'
    ");

    while ($r = mysqli_fetch_assoc($q)) {
        $h = (int)$r['hari'];

        if ($r['status'] == "Hadir") {
            $data[$id_penghuni]['hari'][$h] = "✓";
            $data[$id_penghuni]['hadir_count']++;
            $jumlah_hadir_total++;
            $hadir_per_hari[$h]++;
        } else {
            $data[$id_penghuni]['hari'][$h] = "✗";
            $data[$id_penghuni]['tidak_hadir_count']++;
            $jumlah_tidak_hadir_total++;
        }
    }
}

// Kira statistik
$jumlah_rekod = $jumlah_penghuni * $total_hari;
$peratus_kehadiran = $jumlah_rekod > 0 ? round(($jumlah_hadir_total / $jumlah_rekod) * 100, 2) : 0;

// Data dummy (gantikan dengan data sebenar jika ada)
$sql_masuk = mysqli_query($conn, "
    SELECT COUNT(*) AS total_masuk 
    FROM penghuni
");

$data_masuk = mysqli_fetch_assoc($sql_masuk);
$bil_masuk = $data_masuk['total_masuk'];

$purata_kedatangan = $jumlah_penghuni > 0 ? round($jumlah_hadir_total / $jumlah_penghuni, 2) : 0;
?>

<!DOCTYPE html>
<html lang="ms">
<head>
  <meta charset="UTF-8">
  <title>Laporan Bulanan</title>
  <link rel="stylesheet" href="css/style_sidebar.css">
  <link rel="stylesheet" href="css/style_laporan.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body class="dashboard-page">
<?php include 'inc/sidebar.php'; ?>

<!-- MAIN CONTENT -->
<main class="content">
    <!-- PRINT CONTROL HEADER -->
    <div class="print-header">
        <h3><i class="fas fa-file-alt"></i> LAPORAN KEHADIRAN BULANAN</h3>
        <div class="print-controls">
            <button class="btn btn-print" onclick="printReport()">
                <i class="fas fa-print"></i> Cetak Laporan
            </button>

        </div>
    </div>
    
    <!-- FILTER SECTION -->
    <div class="filter-section">
        <form method="GET" class="filter-form">
            <div class="filter-group">
                <label class="filter-label">Bulan</label>
                <select name="bulan" class="filter-input">
                    <?php for($i=1; $i<=12; $i++): ?>
                        <option value="<?= sprintf("%02d", $i) ?>" <?= $bulan==$i?'selected':'' ?>>
                            <?= date("F", mktime(0,0,0,$i,1)) ?>
                        </option>
                    <?php endfor; ?>
                </select>
            </div>
            
            <div class="filter-group">
                <label class="filter-label">Tahun</label>
                <select name="tahun" class="filter-input">
                    <?php for($t=2023; $t<=date('Y'); $t++): ?>
                        <option value="<?= $t ?>" <?= $tahun==$t?'selected':'' ?>><?= $t ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            
            <div class="filter-group">
                <label class="filter-label">Bilik</label>
                <select name="nama_bilik" class="filter-input">
                    <option value="Semua">Semua Bilik</option>
                    <?php 
                    mysqli_data_seek($list_bilik, 0);
                    while($bilik = mysqli_fetch_assoc($list_bilik)): 
                    ?>
                        <option value="<?= $bilik['nama_bilik'] ?>" <?= $bilik_pilih==$bilik['nama_bilik']?'selected':'' ?>>
                            <?= $bilik['nama_bilik'] ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            
            <button type="submit" class="btn btn-submit">
                <i class="fas fa-search"></i> Papar Laporan
            </button>
        </form>
        
        <!-- LEGEND -->
        <div class="legend">
            <div class="legend-item">
                <div class="legend-box legend-present"></div>
                <span>Hadir (✓)</span>
            </div>
            <div class="legend-item">
                <div class="legend-box legend-absent"></div>
                <span>Tidak Hadir (✗)</span>
            </div>
            <div class="legend-item">
                <div class="legend-box legend-empty"></div>
                <span>Tiada Rekod (-)</span>
            </div>
        </div>
    </div>
    
    <!-- MAIN REPORT CONTAINER -->
<div class="report-container">
    <!-- REPORT HEADER -->
    <div class="report-header">
        <div class="report-title">LAPORAN KEHADIRAN BULANAN</div>
        <div class="report-subtitle">SISTEM PENGURUSAN KEHADIRAN ASRAMA (SPKA)</div>
        <div class="report-period">
            <i class="fas fa-calendar-alt"></i>
            <?php
            // Nama bulan
            $nama_bulan = [
                '01'=>'JANUARI','02'=>'FEBRUARI','03'=>'MAC','04'=>'APRIL',
                '05'=>'MEI','06'=>'JUN','07'=>'JULAI','08'=>'OGOS',
                '09'=>'SEPTEMBER','10'=>'OKTOBER','11'=>'NOVEMBER','12'=>'DISEMBER'
            ];
            echo strtoupper($nama_bulan[$bulan] . " " . $tahun);

            ?>
            <?= $bilik_pilih != "Semua" ? " | Bilik: " . $bilik_pilih : "" ?>
        </div>
    </div>
    
    <!-- ATTENDANCE TABLE -->
    <div class="attendance-table-container">
        <table class="attendance-table">
            <thead>
                <tr>
                    <th>NO.</th>
                    <th>NAMA PENGHUNI</th>
                    <th>BILIK</th>
                    <th>KELAS</th>
                    
                    <!-- DAY COLUMNS - dari 1 hingga akhir bulan -->
                    <?php for($d=1; $d<=$total_hari; $d++): 
                        $dayName = date('D', mktime(0,0,0,$bulan,$d,$tahun));
                        // Tukar nama hari ke bahasa Melayu
                        $hari_melayu = [
                            'Mon' => 'ISN', 'Tue' => 'SEL', 'Wed' => 'RAB', 
                            'Thu' => 'KHA', 'Fri' => 'JUM', 'Sat' => 'SAB', 'Sun' => 'AHAD'
                        ];
                        $hari = $hari_melayu[$dayName] ?? substr($dayName, 0, 3);
                    ?>
                        <th class="day-header">
                            <div class="day-number"><?= str_pad($d,2,'0',STR_PAD_LEFT) ?></div>
                            <div class="day-name"><?= $hari ?></div>
                        </th>
                    <?php endfor; ?>
                    
                    <th>HADIR</th>
                    <th>TIDAK HADIR</th>
                    <th>BULAN LALU</th>
                    <th>AKHIR BULAN</th>
                </tr>
            </thead>
            
            <tbody>
                <?php if($jumlah_penghuni > 0): ?>
                    <?php $counter = 1; ?>
                    <?php foreach($data as $id => $pen): ?>
                        <tr>
                            <td><?= $counter++ ?></td>
                            <td style="text-align: left;"><?= htmlspecialchars($pen['nama']) ?></td>
                            <td><?= $pen['nama_bilik'] ?></td>
                            <td><?= $pen['kelas'] ?></td>
                            
                            <!-- DAY CELLS - dari 1 hingga akhir bulan -->
                            <?php for($d=1; $d<=$total_hari; $d++): 
                                $val = $pen['hari'][$d] ?? '';
                                $cls = '';
                                if($val == '✓' || $val == 'H') $cls = 'status-present';
                                elseif($val == '✗' || $val == 'T' || $val == 'A') $cls = 'status-absent';
                                else $cls = 'status-empty';
                            ?>
                                <td class="<?= $cls ?>">
                                    <?= $val ?>
                                </td>
                            <?php endfor; ?>
                            
                            <td class="status-present"><?= $pen['hadir_count'] ?? 0 ?></td>
                            <td class="status-absent"><?= $pen['tidak_hadir_count'] ?? 0 ?></td>
                            <td class="stats-value"><?= $pen['bulan_lalu'] ?? 0 ?></td>
                            <td class="stats-value"><?= $pen['akhir_bulan'] ?? 0 ?></td>
                        </tr>
                    <?php endforeach; ?>
                    
                    <!-- SUMMARY ROW -->
                    <tr class="summary-row">
                        <td colspan="4"><strong>JUMLAH / PURATA HARIAN</strong></td>
                        
                        <!-- DAILY TOTALS -->
                        <?php for($d=1; $d<=$total_hari; $d++): ?>
                            <td>
                                <strong><?= $hadir_per_hari[$d] ?? 0 ?></strong>
                            </td>
                        <?php endfor; ?>
                        
                        <td><strong><?= $jumlah_hadir_total ?></strong></td>
                        <td><strong><?= $jumlah_tidak_hadir_total ?></strong></td>
                        <td><strong><?= $jumlah_bulan_lalu_total ?? 0 ?></strong></td>
                        <td><strong><?= $jumlah_akhir_bulan_total ?? 0 ?></strong></td>
                    </tr>
                <?php else: ?>
                    <tr>
                        <td colspan="<?= 4 + $total_hari + 4 ?>" style="text-align: center; padding: 40px;">
                            <i class="fas fa-exclamation-circle" style="font-size: 24px; color: #718096; margin-bottom: 10px;"></i>
                            <div style="font-size: 16px; color: #718096;">Tiada data kehadiran untuk bulan ini</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <!-- STATISTICS TABLE -->
    <div class="stats-table-container">
        <table class="stats-table">
            <thead>
                <tr>
                    <th colspan="4">
                        <i class="fas fa-chart-bar"></i>
                        STATISTIK KEHADIRAN BULANAN
                    </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="stats-label">JUMLAH PENGHUNI</td>
                    <td class="stats-value"><?= $jumlah_penghuni ?></td>
                    <td class="stats-label">JUMLAH KEHADIRAN SEPATUTNYA</td>
                    <td class="stats-value"><?= $jumlah_rekod ?></td>
                </tr>
                <tr>
                    <td class="stats-label">JUMLAH PENGHUNI HADIR</td>
                    <td class="stats-value"><?= $jumlah_hadir_total ?></td>
                    <td class="stats-label">PURATA KEDATANGAN</td>
                    <td class="stats-value"><?= $purata_kedatangan ?></td>
                </tr>
                <tr>
                    <td class="stats-label">JUMLAH PENGHUNI TIDAK HADIR</td>
                    <td class="stats-value"><?= $jumlah_tidak_hadir_total ?></td>
                    <td class="stats-label">PERATUS KEDATANGAN</td>
                    <td class="stats-value stats-percentage"><?= $peratus_kehadiran ?>%</td>
                </tr>
                <tr>
                    <td class="stats-label">JUMLAH TIDAK HADIR BULAN INI</td>
                    <td class="stats-value"><?= $jumlah_tidak_hadir_total ?></td>
                    <td class="stats-label">DARI BULAN LALU</td>
                    <td class="stats-value"><?= $jumlah_bulan_lalu_total ?? 0 ?></td>
                </tr>
                <tr>
                    <td class="stats-label">AKHIR BULAN INI</td>
                    <td class="stats-value"><?= $jumlah_akhir_bulan_total ?? 0 ?></td>
                    <td class="stats-label">BIL. PENGHUNI MASUK</td>
                    <td class="stats-value"><?= $bil_masuk ?? 0 ?></td>
                </tr>
            </tbody>
        </table>
    </div>
    
    <!-- REPORT FOOTER -->
    <div class="report-footer">
        <div>Dihasilkan pada: <?= date('d/m/Y H:i:s') ?></div>
        <div>SPKA - Sistem Pengurusan Kehadiran Asrama</div>
    </div>
</div>
    </div>
</main>

<!-- JAVASCRIPT -->
<script>
function printReport() {

    // Dapatkan elemen laporan sahaja 
    let printContent = document.querySelector('.report-container').cloneNode(true);

    // Wujudkan window baru
    let printWindow = window.open('', '', 'width=1000,height=900');

    printWindow.document.write(`
        <html>
        <head>
            <title>Laporan Kehadiran Bulanan - SPKA</title>
            <link rel="stylesheet" href="css/style_laporan.css">
            <style>
                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    padding: 20px;
                }
                .attendance-table th, .attendance-table td {
                    font-size: 11px;
                    padding: 6px 4px;
                }
                .stats-table td, .stats-table th {
                    font-size: 12px;
                }
                @page { size: landscape; }
            </style>
        </head>
        <body>
            ${printContent.innerHTML}
        </body>
        </html>
    `);

    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
}
</script>
</body>
</html>