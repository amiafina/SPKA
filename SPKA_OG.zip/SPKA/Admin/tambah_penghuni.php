<?php
include 'inc/connect.php';
$csv_success = false;

if(isset($_POST['upload_csv']) && isset($_FILES['csv_file'])) {
    $file = $_FILES['csv_file']['tmp_name'];

    if (($handle = fopen($file, "r")) !== FALSE) {
        $header = fgetcsv($handle); // skip header

        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            $nama_penghuni      = strtoupper($conn->real_escape_string($data[0]));
            $nama_bilik         = strtoupper($conn->real_escape_string($data[1]));
            $kelas              = strtoupper($conn->real_escape_string($data[2]));
            $no_tel             = $conn->real_escape_string($data[3]);
            $alamat             = strtoupper($conn->real_escape_string($data[4]));
            $nama_penjaga1      = strtoupper($conn->real_escape_string($data[5]));
            $no_tel_penjaga1    = $conn->real_escape_string($data[6]);
            $hubungan_penjaga1  = strtoupper($conn->real_escape_string($data[7]));
            $nama_penjaga2      = strtoupper($conn->real_escape_string($data[8]));
            $no_tel_penjaga2    = $conn->real_escape_string($data[9]);
            $hubungan_penjaga2  = strtoupper($conn->real_escape_string($data[10]));

            $sql = "INSERT INTO penghuni 
                (nama_penghuni, nama_bilik, kelas, no_tel, alamat, 
                 nama_penjaga1, no_tel_penjaga1, hubungan_penjaga1, 
                 nama_penjaga2, no_tel_penjaga2, hubungan_penjaga2)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param(
                "sssssssssss",
                $nama_penghuni,
                $nama_bilik,
                $kelas,
                $no_tel,
                $alamat,
                $nama_penjaga1,
                $no_tel_penjaga1,
                $hubungan_penjaga1,
                $nama_penjaga2,
                $no_tel_penjaga2,
                $hubungan_penjaga2
            );
            $stmt->execute();
        }
        fclose($handle);
        $csv_success = true;
    }
}
?>

<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tambah Penghuni</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/style_sidebar.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
<style>
body.dashboard-page { display: flex; }
.main-content { margin-left:240px; padding:20px; width:100%; }

/* Footer Minimalis */
.footer {
    background: white;
    color: #64748b;
    text-align: center;
    padding: 20px;
    border-radius: 12px;
    margin-top: auto;
    box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.04);
    border: 1px solid #eef2f7;
    font-size: 14px;
}

.footer b {
    font-weight: 500;
    color: #1e293b;
}

.footer .update-time {
    margin-top: 6px;
    font-size: 13px;
    color: #94a3b8;
}
</style>
</head>
<body class="dashboard-page">

<?php include 'inc/sidebar.php'; ?>

<div class="main-content">
<div class="container-fluid mt-5">
<h4 class="mb-4"><b>📝 Tambah Penghuni Baru</b></h4>

<!-- 🔹 Upload CSV -->
<div class="card mb-4">
  <div class="card-header bg-warning text-dark"><h5>Tambah Penghuni Secara Pukal (CSV)</h5></div>
  <div class="card-body">
    <form action="tambah_penghuni.php" method="POST" enctype="multipart/form-data">
      <div class="mb-3">
        <label for="csv_file" class="form-label">Pilih Fail CSV</label>
        <input type="file" class="form-control" name="csv_file" id="csv_file" accept=".csv" required>
      </div>
      <div class="d-flex gap-2">
        <button type="submit" name="upload_csv" class="btn btn-warning">
            <i class="bi bi-upload"></i> Muat Naik CSV
        </button>
        <a href="template_penghuni.csv" id="download-template" class="btn btn-info text-white" download>
            <i class="bi bi-file-earmark-text"></i> Muat Turun Template CSV
        </a>
      </div>
    </form>
  </div>
</div>

<!-- 🔹 Form Tambah Penghuni Manual -->
<?php if(isset($_GET['success'])): ?>
<div class="alert alert-success">Penghuni berjaya ditambah!</div>
<?php endif; ?>

<form action="proses_tambah.php" method="POST">
<div class="row">
<!-- Maklumat Penghuni -->
<div class="col-md-6">
<div class="card mb-4">
<div class="card-header bg-primary text-white"><h5>Maklumat Penghuni</h5></div>
<div class="card-body">
<div class="mb-3">
<label class="form-label">Nama Penghuni <span class="text-danger">*</span></label>
<input type="text" class="form-control" name="nama_penghuni" required style="text-transform:uppercase;">
</div>
<div class="row">
<div class="col-md-6 mb-3">
<label class="form-label">Nama Bilik<span class="text-danger">*</span></label>
<select name="nama_bilik" class="form-control" required>
    <option value="">Sila Pilih Bilik ▾</option>
    <?php
    $bilik_result = $conn->query("SELECT nama_bilik FROM bilik ORDER BY nama_bilik ASC");
    while($b = $bilik_result->fetch_assoc()){
        echo '<option value="'.htmlspecialchars($b['nama_bilik']).'">'.htmlspecialchars($b['nama_bilik']).'</option>';
    }
    ?>
</select>
</div>
<div class="col-md-6 mb-3">
<label class="form-label">Kelas<span class="text-danger">*</span></label>
<input type="text" class="form-control" name="kelas" required style="text-transform:uppercase;">
</div>
</div>
<div class="mb-3">
<label class="form-label">No. Telefon Penghuni<span class="text-danger">*</span></label>
<input type="tel" class="form-control" name="no_tel" required >
</div>
<div class="mb-3">
<label class="form-label">Alamat<span class="text-danger">*</span></label>
<textarea class="form-control" name="alamat" rows="3" required style="text-transform:uppercase;"></textarea>
</div>
</div>
</div>
</div>

<!-- Maklumat Penjaga -->
<div class="col-md-6">
<div class="card mb-4">
<div class="card-header bg-success text-white"><h5>Maklumat Penjaga</h5></div>
<div class="card-body">

<!-- Penjaga 1 -->
<div class="mb-3">
<label class="form-label">Nama Penjaga 1<span class="text-danger">*</span></label>
<input type="text" class="form-control" name="nama_penjaga1" style="text-transform:uppercase;" required>
</div>
<div class="mb-3">
<label class="form-label">No. Telefon Penjaga 1<span class="text-danger">*</span></label>
<input type="tel" class="form-control" name="no_tel_penjaga1" required>
</div>
<div class="mb-3">
<label class="form-label">Hubungan Penjaga 1<span class="text-danger">*</span></label>
<select class="form-control" name="hubungan_penjaga1" id="hubunganSelect1" required>
    <option value="">Sila Pilih Hubungan ▾</option>
    <option value="ibu">IBU</option>
    <option value="bapa">BAPA</option>
    <option value="adik_beradik">ADIK-BERADIK</option>
    <option value="datuk">DATUK</option>
    <option value="nenek">NENEK</option>
    <option value="lain">LAIN-LAIN</option>
</select>
<input type="text" class="form-control mt-2" name="hubungan_penjaga1_lain" id="lainText1" placeholder="Taip hubungan lain" style="display:none;">
</div>

<hr>

<!-- Penjaga 2 -->
<div class="mb-3">
<label class="form-label">Nama Penjaga 2<span class="text-danger">*</span></label>
<input type="text" class="form-control" name="nama_penjaga2" style="text-transform:uppercase;" required>
</div>
<div class="mb-3">
<label class="form-label">No. Telefon Penjaga 2<span class="text-danger">*</span></label>
<input type="tel" class="form-control" name="no_tel_penjaga2" required>
</div>
<div class="mb-3">
<label class="form-label">Hubungan Penjaga 2<span class="text-danger">*</span></label>
<select class="form-control" name="hubungan_penjaga2" id="hubunganSelect2" required>
    <option value="">Sila Pilih Hubungan ▾</option>
    <option value="ibu">IBU</option>
    <option value="bapa">BAPA</option>
    <option value="adik_beradik">ADIK-BERADIK</option>
    <option value="datuk">DATUK</option>
    <option value="nenek">NENEK</option>
    <option value="lain">LAIN-LAIN</option>
</select>
<input type="text" class="form-control mt-2" name="hubungan_penjaga2_lain" id="lainText2" placeholder="Taip hubungan lain" style="display:none;">
</div>

</div>
</div>
</div>
</div>

<div class="d-flex gap-2">
<button type="submit" class="btn btn-success"><i class="bi bi-save"></i> Simpan</button>
<button type="reset" class="btn btn-outline-danger"><i class="bi bi-eraser"></i> Set Semula</button>
</div>

<br><br><br>
<!-- Footer -->
      <div class="footer">
        <b>© <?php echo date('Y'); ?> SPKA | Sistem Pengurusan Kehadiran Asrama</b>
        <div class="update-time">Dikemaskini: <?php echo date('H:i:s'); ?></div>
      </div>

</form>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
  // CSV Download popup
  document.getElementById('download-template').addEventListener('click', function(e){
    e.preventDefault();
    Swal.fire({
      icon: 'success',
      title: 'Berjaya!',
      text: 'Template CSV telah dimuat turun.',
      timer: 2000,
      timerProgressBar: true,
      showConfirmButton: false
    });
    setTimeout(() => { window.location.href = this.href; }, 500);
  });

  // CSV upload success popup
  <?php if($csv_success): ?>
  Swal.fire({
    icon: 'success',
    title: 'Berjaya!',
    text: 'CSV berjaya dimasukkan ke dalam sistem.',
    timer: 2000,
    timerProgressBar: true,
    showConfirmButton: false
  });
  <?php endif; ?>

  // Hubungan Lain-lain show/hide
  document.getElementById('hubunganSelect1').addEventListener('change', function() {
      document.getElementById('lainText1').style.display = (this.value === 'lain') ? 'block' : 'none';
  });
  document.getElementById('hubunganSelect2').addEventListener('change', function() {
      document.getElementById('lainText2').style.display = (this.value === 'lain') ? 'block' : 'none';
  });
</script>

</body>
</html>
