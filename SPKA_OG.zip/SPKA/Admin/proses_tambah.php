<?php
// Sambungan ke database
$conn = new mysqli('localhost','root','','spka');
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
$conn->set_charset("utf8mb4");

// Ambil data dari form
$nama_penghuni   = isset($_POST['nama_penghuni']) ? strtoupper($_POST['nama_penghuni']) : '';
$nama_bilik      = isset($_POST['nama_bilik']) ? strtoupper($_POST['nama_bilik']) : '';
$kelas           = isset($_POST['kelas']) ? strtoupper($_POST['kelas']) : '';
$no_tel          = $_POST['no_tel'] ?? '';
$nama_penjaga1   = isset($_POST['nama_penjaga1']) ? strtoupper($_POST['nama_penjaga1']) : '';
$no_tel_penjaga1 = $_POST['no_tel_penjaga1'] ?? '';
$hubungan_penjaga1 = isset($_POST['hubungan_penjaga1']) ? strtoupper($_POST['hubungan_penjaga1']) : '';
$nama_penjaga2 = isset($_POST['nama_penjaga2']) ? strtoupper($_POST['nama_penjaga2']) : '';
$no_tel_penjaga2 = $_POST['no_tel_penjaga2'] ?? '';
$hubungan_penjaga2 = isset($_POST['hubungan_penjaga2']) ? strtoupper($_POST['hubungan_penjaga2']) : '';
$alamat          = isset($_POST['alamat']) ? strtoupper($_POST['alamat']) : '';


// Prepare & bind
$sql = "INSERT INTO penghuni 
(nama_penghuni, nama_bilik, kelas, no_tel, nama_penjaga1, no_tel_penjaga1, hubungan_penjaga1, nama_penjaga2, no_tel_penjaga2, hubungan_penjaga2, alamat)
VALUES (?,?,?,?,?,?,?,?,?,?,?)";  // 11 ?
$stmt = $conn->prepare($sql);
$stmt->bind_param(
    "sssssssssss", // 11 s, ikut column
    $nama_penghuni,
    $nama_bilik,
    $kelas,
    $no_tel,
    $nama_penjaga1,
    $no_tel_penjaga1,
    $hubungan_penjaga1,
    $nama_penjaga2,
    $no_tel_penjaga2,
    $hubungan_penjaga2,
    $alamat
);


// Execute
if($stmt->execute()){
    header("Location: tambah_penghuni.php?success=1");
    exit();
}else{
    echo "Error: ".$stmt->error;
}

$stmt->close();
$conn->close();
?>
