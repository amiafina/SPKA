  <aside class="sidebar">
    <h2>SPKA</h2>

    <ul class="sidebar-menu">
        <li class="active">
            <a href="../KetuaBilik/kehadiran_ketua_bilik.php">
                <img src="../Admin/inc/gambar/kehadiran.png" class="icon">
                <span>Kehadiran</span>
            </a>
        </li>

        <li>
            <a href="#" id="btnInfo">
                <img src="../Admin/inc/gambar/info.png" class="icon">
                <span>Info</span>
            </a>
        </li>

        <li>
            <a href="../Admin/index.php" onclick="logoutConfirm(event)">
                <img src="../Admin/inc/gambar/logout.png" class="icon">
                <span>Log Keluar</span>
            </a>
        </li>
    </ul>
</aside>
