<aside class="sidebar">
    <h2>SPKA</h2>
    <ul class="sidebar-menu">
      <li class="<?php echo (basename($_SERVER['PHP_SELF']) == 'dashboard_admin.php') ? 'active' : ''; ?>">
        <a href="dashboard_admin.php">
            <img src="inc/gambar/dashboard.png" class="icon">
            <span>Papan Muka</span>
        </a>
      </li>
      <li class="<?php echo (basename($_SERVER['PHP_SELF']) == 'kehadiran.php') ? 'active' : ''; ?>">
        <a href="kehadiran.php">
          <img src="inc/gambar/kehadiran.png" class="icon">
          <span>Kehadiran</span>
        </a>
      </li>
      <li class="<?php echo (basename($_SERVER['PHP_SELF']) == 'laporan_bulanan.php') ? 'active' : ''; ?>">
        <a href="laporan_bulanan.php">
          <img src="inc/gambar/laporan.png" class="icon">
          <span>Laporan Bulanan</span>
        </a>
      </li>
      <li class="<?php echo (basename($_SERVER['PHP_SELF']) == 'info.php') ? 'active' : ''; ?>">
        <a href="info.php">
          <img src="inc/gambar/info.png" class="icon">
          <span>Info</span>
        </a>
      </li>
      <li class="<?php echo (basename($_SERVER['PHP_SELF']) == 'maklumat_penghuni.php') ? 'active' : ''; ?>">
        <a href="maklumat_penghuni.php">
          <img src="inc/gambar/user.png" class="icon">
          <span>Maklumat Penghuni</span>
        </a>
      </li>
      <li class="<?php echo (basename($_SERVER['PHP_SELF']) == 'tambah_penghuni.php') ? 'active' : ''; ?>">
        <a href="tambah_penghuni.php">
          <img src="inc/gambar/add.png" class="icon">
          <span>Tambah Penghuni</span>
        </a>
      </li>
      <br><br>
      <li>
        <a href="../Admin/index.php" onclick="return logoutConfirm(event)">
          <img src="inc/gambar/logout.png" class="icon">
          <span>Log Keluar</span>
        </a>
      </li>
    </ul>
</aside>
<script>
// LOGOUT SWEETALERT2
function logoutConfirm(event) {
    event.preventDefault();
    Swal.fire({
        title: 'Adakah anda ingin keluar?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya',
        cancelButtonText: 'Tidak',
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = '../Admin/index.php';
        }
    });
}
</script>