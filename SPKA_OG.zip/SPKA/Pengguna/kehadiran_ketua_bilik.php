<?php
session_start();
if(!isset($_SESSION['nama_pengguna']) || $_SESSION['peranan'] != 'ketua_bilik'){
    header("Location: ../Admin/index.php");
    exit();
}

include '../Admin/inc/connect.php';

// SET TIMEZONE
date_default_timezone_set('Asia/Kuala_Lumpur');

// Dapatkan nama bilik ikut ketua bilik
$nama_pengguna = $_SESSION['nama_pengguna'];
$query_bilik = mysqli_query($conn, "SELECT nama_bilik FROM pengguna WHERE nama_pengguna='$nama_pengguna' AND peranan='ketua_bilik' LIMIT 1");
$bilik_row = mysqli_fetch_assoc($query_bilik);
$nama_bilik = $bilik_row['nama_bilik'];

// Tarikh hari ini
$tarikh_hari_ini = date('Y-m-d');
$masa_sekarang = date('H:i');

// Flag kehadiran ditutup (ubah mengikut keperluan)
// $kehadiran_ditutup = false;
// // Contoh: Kehadiran hanya dibuka dari 9PM hingga 10PM
// if ($masa_sekarang < '21:00' || $masa_sekarang > '00:15') {
//   $kehadiran_ditutup = true;
// }

// Kod baru masa tutup 
$masa_sekarang = date('H:i'); // ambil masa sekarang 24-jam

$buka  = '21:15';
$tutup = '22:30';

if ($masa_sekarang >= $buka && $masa_sekarang <= $tutup) {
    $kehadiran_ditutup = false; // MASIH BUKA
} else {
    $kehadiran_ditutup = true;  // TUTUP
}


// Dapatkan senarai penghuni dalam bilik ini
$result = mysqli_query($conn, "SELECT id_penghuni, nama_penghuni FROM penghuni WHERE nama_bilik='$nama_bilik' ORDER BY nama_penghuni ASC");
$total_pelajar = mysqli_num_rows($result);

// Default nilai - SEMUA DIANGGAP HADIR
$bil_hadir = $total_pelajar;
$bil_tak_hadir = 0;

// Flag untuk popup
$show_success = false;

// Ambil data kehadiran sedia ada untuk hari ini
$hadir_today = [];
if($result && $total_pelajar > 0) {
    mysqli_data_seek($result, 0); // Reset pointer
    
    // Dapatkan semua id penghuni
    $id_penghuni_array = [];
    while($row = mysqli_fetch_assoc($result)) {
        $id_penghuni_array[] = $row['id_penghuni'];
    }
    
    // Query kehadiran untuk hari ini
    if(!empty($id_penghuni_array)) {
        $id_list = "'" . implode("','", $id_penghuni_array) . "'";
        $check_query = mysqli_query($conn, 
            "SELECT id_penghuni, status, catatan 
             FROM kehadiran 
             WHERE id_penghuni IN ($id_list) 
             AND DATE(tarikh) = DATE('$tarikh_hari_ini')");
        
        // Reset count
        $bil_hadir = 0;
        $bil_tak_hadir = 0;
        
        while($row_check = mysqli_fetch_assoc($check_query)){
            $hadir_today[$row_check['id_penghuni']] = $row_check;
            if($row_check['status'] == 'Hadir') {
                $bil_hadir++;
            } else {
                $bil_tak_hadir++;
            }
        }
        
        // Untuk penghuni yang belum ada rekod, dianggap HADIR
        $bil_hadir += ($total_pelajar - count($hadir_today));
    }
    
    mysqli_data_seek($result, 0); // Reset pointer untuk paparan
}

// Bila ketua bilik submit kehadiran
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_kehadiran']) && !$kehadiran_ditutup) {
    if(isset($_POST['id_penghuni'])) {
        $hadir = isset($_POST['hadir']) ? $_POST['hadir'] : [];
        $bil_hadir = count($hadir);
        $bil_tak_hadir = $total_pelajar - $bil_hadir;
        
        $berjaya = true;
        
        // Simpan rekod kehadiran
        foreach ($_POST['id_penghuni'] as $id) {
            $id_safe = mysqli_real_escape_string($conn, $id);
            $status = in_array($id, $hadir) ? 'Hadir' : 'Tidak Hadir';
            $catatan = isset($_POST['catatan'][$id]) ? $_POST['catatan'][$id] : '';
            $lain = isset($_POST['lain'][$id]) ? $_POST['lain'][$id] : '';
            
            // Jika hadir, reset catatan
            if($status == 'Hadir') {
                $catatan = '';
            } else {
                // Jika tidak hadir dan pilih Lain-lain
                if($catatan == 'Lain-lain' && $lain != ''){
                    $catatan = $lain;
                }
                
                // Validasi: Jika tidak hadir, mesti ada catatan
                if(empty($catatan)) {
                    $catatan = 'Tiada maklumat';
                }
            }
            
            $catatan_safe = mysqli_real_escape_string($conn, $catatan);
            
            // Gunakan REPLACE untuk overwrite data sedia ada
            $sql = "REPLACE INTO kehadiran (id_penghuni, tarikh, status, catatan)
                    VALUES ('$id_safe', '$tarikh_hari_ini', '$status', '$catatan_safe')";
            
            if(!mysqli_query($conn, $sql)) {
                $berjaya = false;
                error_log("Error saving attendance: " . mysqli_error($conn));
            }
        }
        
        if($berjaya) {
            $show_success = true;
            
            // Refresh data kehadiran
            $hadir_today = [];
            if(!empty($id_penghuni_array)) {
                $id_list = "'" . implode("','", $id_penghuni_array) . "'";
                $check_query = mysqli_query($conn, 
                    "SELECT id_penghuni, status, catatan 
                     FROM kehadiran 
                     WHERE id_penghuni IN ($id_list) 
                     AND DATE(tarikh) = DATE('$tarikh_hari_ini')");
                
                while($row_check = mysqli_fetch_assoc($check_query)){
                    $hadir_today[$row_check['id_penghuni']] = $row_check;
                }
            }
        }
    }
}
$info_result = mysqli_query($conn, "SELECT * FROM info_files ORDER BY id ASC");
$info_count = mysqli_num_rows($info_result);
// Reset pointer untuk paparan dalam modal
mysqli_data_seek($info_result, 0);
?>

<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8">
<title>Kehadiran Ketua Bilik</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="../Admin/css/style_sidebar.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<style>
* { font-family: 'Roboto', sans-serif; }
body.dashboard-page { background: #f8f9fa; margin: 0; padding: 0; }
.content {
    margin-left: 240px;       /* ikut sidebar */
    padding: 20px;
    width: calc(100% - 240px);
    min-height: 100vh;
    background: #f8f9fa;
    overflow-x: auto; 
}
#bilik { border: none; background: transparent; font-size: 28px; font-weight: 700; color: #2c3e50; text-transform: uppercase; margin: 10px 0 20px 0; padding: 0; }
.form-group { margin-bottom: 15px; display: flex; align-items: center; }
.form-group label { font-weight: 600; color: #2c3e50; min-width: 150px; font-size: 14px; }
.form-group input[type="text"] { padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 14px; color: #2c3e50; background: #f8f9fa; width: 200px; }
hr { border: none; border-top: 1px solid #ddd; margin: 20px 0; }
.table-container { background: white; border-radius: 10px; padding: 20px; margin: 20px 0; box-shadow: 0 2px 10px rgba(0,0,0,0.05); border: 1px solid #eaeaea; overflow-x: auto; }
.attendance-table { width: 100%; min-width: 600px; border-collapse: collapse; font-size: 14px; }
.attendance-table thead { background: #2c3e50; color: white; }
.attendance-table th { padding: 14px 12px; text-align: center; font-weight: 600; }
.attendance-table td { padding: 12px 10px; border-bottom: 1px solid #f0f0f0; text-align: center; color: #333; }
.attendance-table td:nth-child(1) { width: 50px; font-weight: 500; color: #2c3e50; }
.attendance-table td:nth-child(2) { width: 80px; }
.attendance-table td:nth-child(3) { text-align: left; padding-left: 15px; font-weight: 500; color: #2c3e50; }
.attendance-table td:nth-child(4) { width: 250px; }
.attendance-table input[type="checkbox"] { width: 18px; height: 18px; cursor: pointer; accent-color: #3a6d50; }
.attendance-table select { width: 100%; padding: 8px 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 13px; color: #333; background: white; cursor: pointer; }
.attendance-table input[type="text"] { width: 100%; padding: 8px 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 13px; color: #333; box-sizing: border-box; }
.attendance-table tbody tr:hover { background-color: #f8fafc; }
.lainInput { display: none; margin-top: 8px; }
button[type="submit"] { background: #27ae60; color: white; border: none; padding: 12px 30px; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; margin-top: 20px; }
button[type="submit"]:hover:not(:disabled) { background: #219653; }
button[type="submit"]:disabled { background: #95a5a6; cursor: not-allowed; opacity: 0.7; }
.warning-box { font-weight: 500; background: #fff3cd; color: #856404; padding: 12px 15px; border-radius: 8px; border-left: 4px solid #ffc107; margin: 20px 0; font-size:15px; }
.hadir-count { color: #27ae60; font-weight: bold; }
.tak-hadir-count { color: #e74c3c; font-weight: bold; }
.catatan-disabled { opacity: 0.6; cursor: not-allowed; }

.table-container {
    max-width: 100%;        /* jangan exceed viewport */
    overflow-x: auto;       /* scroll bila perlu */
}

.attendance-table {
    width: 100%;            /* ikut container */
    min-width: 500px;       /* tak terlalu sempit */
    border-collapse: collapse;
}
@media (max-width: 768px) {
    .content {
        margin-left: 0;
        width: 100%;
        padding: 15px;
    }

    .attendance-table {
        font-size: 12px;
    }

    .attendance-table th,
    .attendance-table td {
        padding: 6px 8px;
    }
}

/* Popup style */
    .modal {
        display: none;
        position: fixed;
        z-index: 9999;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0,0,0,0.5);
    }
        .modal-content {
        background: #fff;
        margin: 5vh auto;          
        padding: 20px;
        border-radius: 10px;
        width: 70%;
        max-width: 600px;
        max-height: 90vh;          
        overflow: hidden;          
        box-shadow: 0px 0px 10px rgba(0,0,0,0.3);
        text-align: center;
    }
        .modal-body-scroll {
        max-height: 65vh;
        overflow-y: auto;
        padding-right: 5px;
    }

    .close {
        float: right;
        font-size: 24px;
        cursor: pointer;
    }
    a.download-link { 
      color: #007bff; text-decoration: none; 
    }
    a.download-link:hover { 
      text-decoration: underline; 
    }
</style>
</head>

<body class="dashboard-page">
<?php include '../Admin/inc/sidebar_ketua_bilik.php'; ?>

<main class="content">
<form method="POST" id="formKehadiran">
<input type="hidden" name="submit_kehadiran" value="1">

<!-- Header Info -->
<div style="margin-bottom: 25px;">
    <input type="text" id="bilik" value="<?php echo htmlspecialchars($nama_bilik); ?>" readonly>
</div>

<div class="form-group">
    <label>TARIKH:</label>
    <input type="text" value="<?php echo date('d/m/Y', strtotime($tarikh_hari_ini)); ?>" readonly>
</div>

<hr>

<div style="display: flex; gap: 30px; margin-bottom: 20px;">
    <div class="form-group">
        <label>BIL. HADIR:</label>
        <input type="text" id="bilHadirDisplay" value="<?= $bil_hadir ?>" readonly class="hadir-count">
    </div>
    <div class="form-group">
        <label>BIL. TIDAK HADIR:</label>
        <input type="text" id="bilTakHadirDisplay" value="<?= $bil_tak_hadir ?>" readonly class="tak-hadir-count">
    </div>
</div>

<?php if($kehadiran_ditutup): ?>
<div class="warning-box">
    KEHADIRAN TELAH DITUTUP. Masa operasi: 9:15 PM - 10:30 PM sahaja.
</div>
<?php else: ?>
<div class="warning-box">
    !! PERHATIAN: KEHADIRAN TIDAK BOLEH DIISI SELEPAS JAM 10:30 PM .
</div>
<?php endif; ?>

<?php if($result && $total_pelajar > 0): ?>
<div class="table-container">
    <table class="attendance-table">
        <thead>
            <tr>
                <th>BIL</th>
                <th>KEHADIRAN</th>
                <th>NAMA PENGHUNI</th>
                <th>CATATAN</th>
            </tr>
        </thead>
        <tbody>
            <?php $i=1; while($row = mysqli_fetch_assoc($result)):
                $hadir_status = isset($hadir_today[$row['id_penghuni']]) ? $hadir_today[$row['id_penghuni']] : null;
                
                // DEFAULT: SEMUA HADIR (checkbox checked)
                // Hanya uncheck jika status dalam database adalah "Tidak Hadir"
                $checked = true;
                if($hadir_status && $hadir_status['status'] == 'Tidak Hadir') {
                    $checked = false;
                }
                
                $catatan_simpan = ($hadir_status && isset($hadir_status['catatan'])) ? $hadir_status['catatan'] : '';
                
                // Tentukan sama ada catatan adalah "Lain-lain"
                // $is_lain_lain = ($catatan_simpan != "" && $catatan_simpan != "Urusan Keluarga" && $catatan_simpan != "Kesihatan" && $catatan_simpan != "Tiada maklumat");
                $kategori_standard = [
                "Urusan Keluarga",
                "Kesihatan",
                "Balik Pilihan",
                "Urusan Rasmi"
                ];

                $is_lain_lain = (
                    $catatan_simpan != "" &&
                    !in_array($catatan_simpan, $kategori_standard)
                );
            ?>
            <tr>
                <td><?= $i++; ?></td>
                <td>
                    <input type="checkbox" 
                           name="hadir[]" 
                           value="<?= $row['id_penghuni']; ?>" 
                           <?= $checked ? 'checked' : ''; ?> 
                           <?= $kehadiran_ditutup ? 'disabled' : ''; ?>
                           class="hadir-checkbox"
                           data-id="<?= $row['id_penghuni']; ?>">
                </td>
                <td><?= htmlspecialchars($row['nama_penghuni']); ?></td>
                <td>
                    <select name="catatan[<?= $row['id_penghuni']; ?>]" 
                            class="catatanSelect" 
                            <?= $kehadiran_ditutup ? 'disabled' : ''; ?>
                            <?= $checked ? 'disabled' : ''; ?>
                            data-id="<?= $row['id_penghuni']; ?>">
                        <option value="" <?= $catatan_simpan==""?'selected':''; ?>>Sila pilih</option>
                        <option value="Balik Pilihan" <?= $catatan_simpan=="Balik Pilihan"?'selected':''; ?>>Balik Pilihan</option>
                        <option value="Urusan Keluarga" <?= $catatan_simpan=="Urusan Keluarga"?'selected':''; ?>>Urusan Keluarga</option>
                        <option value="Urusan Rasmi" <?= $catatan_simpan=="Urusan Rasmi"?'selected':''; ?>>Urusan Rasmi</option>
                        <option value="Kesihatan" <?= $catatan_simpan=="Kesihatan"?'selected':''; ?>>Kesihatan</option>
                        <option value="Lain-lain" <?= $is_lain_lain?'selected':''; ?>>Lain-lain</option>
                    </select>
                    <input type="text" 
                           name="lain[<?= $row['id_penghuni']; ?>]" 
                           class="lainInput"
                           value="<?= $is_lain_lain ? htmlspecialchars($catatan_simpan) : ''; ?>"
                           placeholder="Nyatakan sebab"
                           <?= $kehadiran_ditutup?'readonly':''; ?>
                           <?= $checked ? 'readonly' : ''; ?>
                           data-id="<?= $row['id_penghuni']; ?>">
                </td>
                <input type="hidden" name="id_penghuni[]" value="<?= $row['id_penghuni']; ?>">
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<div style="display:flex; justify-content:flex-end; margin-top:10px;">
    <button type="submit" <?= $kehadiran_ditutup?'disabled style="opacity:0.6; cursor:not-allowed;"':''; ?>>
        <i class="fas fa-paper-plane" style="margin-right: 8px;"></i> HANTAR
    </button>
</div>

<?php else: ?>
<div class="warning-box">
    Tiada penghuni ditemui dalam bilik ini.
</div>
<?php endif; ?>

</form>
</main>

<!-- POPUP INFO -->
  <!-- POPUP INFO -->
<div id="infoModal" class="modal">
    <div class="modal-content">
        <span class="close" id="closeModal">&times;</span>
        <h3>INFO KOLEJ KEDIAMAN</h3>
        <?php if($info_count > 0): ?>
        <div class="modal-body-scroll">
            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="background: #2c3e50; color: white;">
                        <th style="padding: 10px; width: 60px;">BIL</th>
                        <th style="padding: 10px; text-align: left;">TAJUK FAIL</th>
                        <th style="padding: 10px; width: 150px;">MUAT TURUN</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $i = 1;
                    while($info = mysqli_fetch_assoc($info_result)): 
                    ?>
                    <tr>
                        <td style="padding: 10px; text-align: center; border-bottom: 1px solid #eee;"><?= $i++; ?></td>
                        <td style="padding: 10px; border-bottom: 1px solid #eee; text-align: left;"><?= htmlspecialchars($info['title']); ?></td>
                        <td style="padding: 10px; text-align: center; border-bottom: 1px solid #eee;">
                            <a class="download-link" href="../Admin/uploads/info/<?= $info['filename']; ?>" target="_blank" style="color: #007bff; text-decoration: none;">
                                📥 Muat Turun
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <p style="padding: 20px; color: #777;">Tiada info untuk dipaparkan</p>
        <?php endif; ?>
    </div>
</div>

<script>
// Show/hide "Lain-lain" input
document.addEventListener('DOMContentLoaded', function() {
    // Initialize all select elements
    document.querySelectorAll('.catatanSelect').forEach(select => {
        // Set initial state
        let inputLain = select.nextElementSibling;
        if(select.value == 'Lain-lain'){ 
            inputLain.style.display = 'block';
        }
        
        // Add change event
        select.addEventListener('change', function(){
            let inputLain = this.nextElementSibling;
            if(this.value == 'Lain-lain'){ 
                inputLain.style.display = 'block';
                inputLain.focus();
            } else { 
                inputLain.style.display = 'none'; 
                inputLain.value = ''; 
            }
        });
    });
    
    // Function to update attendance counts
    function updateAttendanceCounts() {
        let totalCheckboxes = document.querySelectorAll('.hadir-checkbox').length;
        let checkedCount = document.querySelectorAll('.hadir-checkbox:checked').length;
        let uncheckedCount = totalCheckboxes - checkedCount;
        
        document.getElementById('bilHadirDisplay').value = checkedCount;
        document.getElementById('bilTakHadirDisplay').value = uncheckedCount;
    }
    
    // Toggle catatan fields based on checkbox state
    document.querySelectorAll('.hadir-checkbox').forEach(checkbox => {
        const id = checkbox.getAttribute('data-id');
        const catatanSelect = document.querySelector(`.catatanSelect[data-id="${id}"]`);
        const lainInput = document.querySelector(`.lainInput[data-id="${id}"]`);
        
        // Set initial state
        if(checkbox.checked) {
            if(catatanSelect) {
                catatanSelect.disabled = true;
                catatanSelect.style.opacity = '0.6';
                catatanSelect.style.cursor = 'not-allowed';
            }
            if(lainInput) {
                lainInput.disabled = true;
                lainInput.style.opacity = '0.6';
                lainInput.style.cursor = 'not-allowed';
                lainInput.style.display = 'none';
            }
        }
        
        // Add change event
        checkbox.addEventListener('change', function() {
            if(catatanSelect) {
                catatanSelect.disabled = this.checked;
                catatanSelect.style.opacity = this.checked ? '0.6' : '1';
                catatanSelect.style.cursor = this.checked ? 'not-allowed' : 'pointer';
                
                // Reset catatan jika hadir
                if(this.checked) {
                    catatanSelect.value = '';
                    if(lainInput) {
                        lainInput.value = '';
                        lainInput.style.display = 'none';
                    }
                }
            }
            
            if(lainInput) {
                lainInput.disabled = this.checked;
                lainInput.style.opacity = this.checked ? '0.6' : '1';
                lainInput.style.cursor = this.checked ? 'not-allowed' : 'text';
            }
            
            // Update counts
            updateAttendanceCounts();
        });
    });
    
    // Update counts on page load
    updateAttendanceCounts();
    
    // Form validation
    document.getElementById('formKehadiran').addEventListener('submit', function(e) {
        let valid = true;
        let firstError = null;
        
        document.querySelectorAll('tbody tr').forEach(row => {
            let checkbox = row.querySelector('.hadir-checkbox');
            let select = row.querySelector('.catatanSelect');
            let lainInput = row.querySelector('.lainInput');
            
            // Jika TIDAK hadir (checkbox tidak checked)
            if(checkbox && !checkbox.checked) {
                // Periksa catatan
                if(select && select.value === '') {
                    valid = false;
                    if(!firstError) firstError = select;
                    
                    // Highlight select
                    select.style.borderColor = '#e74c3c';
                    select.style.backgroundColor = '#ffeaea';
                } else if(select && select.value === 'Lain-lain') {
                    // Periksa input lain-lain
                    if(lainInput && lainInput.value.trim() === '') {
                        valid = false;
                        if(!firstError) firstError = lainInput;
                        
                        lainInput.style.borderColor = '#e74c3c';
                        lainInput.style.backgroundColor = '#ffeaea';
                    }
                }
            }
        });
        
        if(!valid) {
            e.preventDefault();
            Swal.fire({
                title: 'Peringatan!',
                text: 'Sila isi catatan bagi penghuni yang tidak hadir.',
                icon: 'warning',
                confirmButtonText: 'OK'
            });
            
            if(firstError) {
                firstError.focus();
                firstError.style.borderColor = '#e74c3c';
            }
        }
    });
});

// Popup info
const modal = document.getElementById('infoModal');
const btn = document.querySelector('a[href="#info"]'); // Sesuaikan dengan link di sidebar
const span = document.getElementById('closeModal');

if(btn) {
    btn.onclick = (e) => { 
        e.preventDefault(); 
        modal.style.display = 'block'; 
    };
}

if(span) {
    span.onclick = () => modal.style.display = 'none';
}

window.onclick = e => { 
    if (e.target == modal) modal.style.display = 'none'; 
};

// Jika ada button dengan id btnInfo
const btnInfo = document.getElementById('btnInfo');
if(btnInfo) {
    btnInfo.onclick = (e) => { 
        e.preventDefault(); 
        modal.style.display = 'block'; 
    };
}

// LOGOUT SWEETALERT2
function logoutConfirm(event) {
    event.preventDefault();
    Swal.fire({
        title: 'Adakah anda ingin keluar?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya',
        cancelButtonText: 'Tidak',
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = '../Admin/index.php';
        }
    });
}

// Popup berjaya
<?php if($show_success): ?>
Swal.fire({
    title: 'Berjaya!', 
    text: 'Rekod kehadiran berjaya dihantar.', 
    icon: 'success', 
    confirmButtonText: 'OK', 
    timer: 3000, 
    timerProgressBar: true
});
<?php endif; ?>
</script>
</body>
</html>